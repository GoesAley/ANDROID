package com.example.a460a21sistemadegestiondemedicamentos.domain.alarm

import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication

/**
 * Interfaz para la programación y cancelación de alarmas del sistema.
 */
interface AlarmScheduler {
    fun scheduleNextAlarm(medication: Medication)
    fun cancelAlarm(medicationId: Long)
}
