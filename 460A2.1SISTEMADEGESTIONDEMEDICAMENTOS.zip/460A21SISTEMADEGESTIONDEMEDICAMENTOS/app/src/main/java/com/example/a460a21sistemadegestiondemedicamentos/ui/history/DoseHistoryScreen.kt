package com.example.a460a21sistemadegestiondemedicamentos.ui.history

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.a460a21sistemadegestiondemedicamentos.R
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.DoseLog
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.DoseStatus
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.FrequencyType
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import com.example.a460a21sistemadegestiondemedicamentos.domain.usecase.DoseHistoryDisplayItem
import com.example.a460a21sistemadegestiondemedicamentos.ui.theme._460A21SISTEMADEGESTIONDEMEDICAMENTOSTheme
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Composable
fun DoseHistoryScreen(
    onNavigateBack: () -> Unit,
    viewModel: DoseHistoryViewModel = hiltViewModel()
) {
    val historyItems by viewModel.historyItems.collectAsStateWithLifecycle()
    val availableMedications by viewModel.availableMedications.collectAsStateWithLifecycle()
    val filterState by viewModel.filterState.collectAsStateWithLifecycle()

    DoseHistoryContent(
        historyItems = historyItems,
        availableMedications = availableMedications,
        filterState = filterState,
        onNavigateBack = onNavigateBack,
        onSelectMedicationFilter = viewModel::onSelectMedicationFilter,
        onDateRangeSelected = viewModel::onDateRangeSelected,
        onClearFilters = viewModel::clearFilters
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DoseHistoryContent(
    historyItems: List<DoseHistoryDisplayItem>,
    availableMedications: List<Medication>,
    filterState: HistoryFilterState,
    onNavigateBack: () -> Unit,
    onSelectMedicationFilter: (Long?) -> Unit,
    onDateRangeSelected: (LocalDate?, LocalDate?) -> Unit,
    onClearFilters: () -> Unit
) {
    val context = LocalContext.current
    val dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy")
    val dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.title_dose_history)) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            // Sección de Filtros de Medicamento
            Text(
                text = "Filtrar por medicamento",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = filterState.selectedMedicationId == null,
                        onClick = { onSelectMedicationFilter(null) },
                        label = { Text(stringResource(R.string.filter_all_medications)) }
                    )
                }

                items(availableMedications, key = { it.id }) { med ->
                    FilterChip(
                        selected = filterState.selectedMedicationId == med.id,
                        onClick = { onSelectMedicationFilter(med.id) },
                        label = { Text(med.name) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Sección de Filtros por Rango de Fechas
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(
                    onClick = {
                        val current = filterState.startDate ?: LocalDate.now()
                        DatePickerDialog(
                            context,
                            { _, year, month, dayOfMonth ->
                                val newStart = LocalDate.of(year, month + 1, dayOfMonth)
                                onDateRangeSelected(newStart, filterState.endDate)
                            },
                            current.year,
                            current.monthValue - 1,
                            current.dayOfMonth
                        ).show()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.DateRange, contentDescription = null)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = filterState.startDate?.let { stringResource(R.string.filter_date_start, it.format(dateFormatter)) } ?: "Desde"
                    )
                }

                OutlinedButton(
                    onClick = {
                        val current = filterState.endDate ?: LocalDate.now()
                        DatePickerDialog(
                            context,
                            { _, year, month, dayOfMonth ->
                                val newEnd = LocalDate.of(year, month + 1, dayOfMonth)
                                onDateRangeSelected(filterState.startDate, newEnd)
                            },
                            current.year,
                            current.monthValue - 1,
                            current.dayOfMonth
                        ).show()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.DateRange, contentDescription = null)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = filterState.endDate?.let { stringResource(R.string.filter_date_end, it.format(dateFormatter)) } ?: "Hasta"
                    )
                }
            }

            if (filterState.selectedMedicationId != null || filterState.startDate != null || filterState.endDate != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onClearFilters) {
                        Icon(imageVector = Icons.Default.Clear, contentDescription = null)
                        Text(stringResource(R.string.clear_filters))
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Lista del Historial
            if (historyItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = stringResource(R.string.no_dose_history),
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(historyItems, key = { it.doseLog.id }) { item ->
                        DoseHistoryCard(item = item, dateTimeFormatter = dateTimeFormatter)
                    }
                }
            }
        }
    }
}

@Composable
fun DoseHistoryCard(
    item: DoseHistoryDisplayItem,
    dateTimeFormatter: DateTimeFormatter
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.medicationName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Dosis: ${item.dosage}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                DoseStatusBadge(status = item.doseLog.status)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = stringResource(R.string.scheduled_at, item.doseLog.scheduledDateTime.format(dateTimeFormatter)),
                style = MaterialTheme.typography.bodySmall
            )

            item.doseLog.actionDateTime?.let { actionTime ->
                Text(
                    text = stringResource(R.string.action_at, actionTime.format(dateTimeFormatter)),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun DoseStatusBadge(status: DoseStatus) {
    val (backgroundColor, textColor, labelRes) = when (status) {
        DoseStatus.TAKEN -> Triple(Color(0xFFD4EDDA), Color(0xFF155724), R.string.status_taken)
        DoseStatus.SKIPPED -> Triple(Color(0xFFF8D7DA), Color(0xFF721C24), R.string.status_skipped)
        DoseStatus.POSTPONED -> Triple(Color(0xFFFFF3CD), Color(0xFF856404), R.string.status_postponed)
        DoseStatus.PENDING -> Triple(Color(0xFFE2E3E5), Color(0xFF383D41), R.string.status_pending)
    }

    Surface(
        color = backgroundColor,
        shape = MaterialTheme.shapes.small,
        modifier = Modifier.padding(start = 8.dp)
    ) {
        Text(
            text = stringResource(labelRes),
            color = textColor,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Preview(showBackground = true)
@Composable
fun DoseHistoryScreenPreview() {
    val now = LocalDateTime.now()
    _460A21SISTEMADEGESTIONDEMEDICAMENTOSTheme {
        DoseHistoryContent(
            historyItems = listOf(
                DoseHistoryDisplayItem(
                    doseLog = DoseLog(
                        id = 1,
                        medicationId = 1,
                        scheduledDateTime = now.minusHours(2),
                        actionDateTime = now.minusHours(2).plusMinutes(2),
                        status = DoseStatus.TAKEN
                    ),
                    medicationName = "Paracetamol",
                    dosage = "500 mg"
                ),
                DoseHistoryDisplayItem(
                    doseLog = DoseLog(
                        id = 2,
                        medicationId = 2,
                        scheduledDateTime = now.minusDays(1),
                        actionDateTime = null,
                        status = DoseStatus.SKIPPED
                    ),
                    medicationName = "Ibuprofeno",
                    dosage = "400 mg"
                )
            ),
            availableMedications = listOf(
                Medication(
                    id = 1,
                    name = "Paracetamol",
                    dosage = "500 mg",
                    frequencyType = FrequencyType.EVERY_X_HOURS,
                    intervalHours = 8,
                    startDateTime = now,
                    currentStock = 20,
                    minStockThreshold = 5
                )
            ),
            filterState = HistoryFilterState(),
            onNavigateBack = {},
            onSelectMedicationFilter = {},
            onDateRangeSelected = { _, _ -> },
            onClearFilters = {}
        )
    }
}
