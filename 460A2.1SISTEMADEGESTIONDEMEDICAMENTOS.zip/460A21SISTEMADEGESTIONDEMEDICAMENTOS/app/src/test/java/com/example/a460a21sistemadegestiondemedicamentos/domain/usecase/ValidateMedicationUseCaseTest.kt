package com.example.a460a21sistemadegestiondemedicamentos.domain.usecase

import com.example.a460a21sistemadegestiondemedicamentos.R
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.FrequencyType
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.time.DayOfWeek
import java.time.LocalDateTime

class ValidateMedicationUseCaseTest {

    private lateinit var validateUseCase: ValidateMedicationUseCase

    @Before
    fun setUp() {
        validateUseCase = ValidateMedicationUseCase()
    }

    @Test
    fun validMedication_returnsValidResult() {
        val medication = Medication(
            name = "Ibuprofeno",
            dosage = "400 mg",
            frequencyType = FrequencyType.EVERY_X_HOURS,
            intervalHours = 8,
            startDateTime = LocalDateTime.now(),
            currentStock = 20,
            minStockThreshold = 5
        )

        val result = validateUseCase(medication)

        assertTrue(result.isValid)
        assertNull(result.nameError)
        assertNull(result.dosageError)
        assertNull(result.intervalError)
    }

    @Test
    fun emptyNameAndDosage_returnsErrors() {
        val medication = Medication(
            name = "",
            dosage = "",
            frequencyType = FrequencyType.EVERY_X_HOURS,
            intervalHours = 8,
            startDateTime = LocalDateTime.now(),
            currentStock = 10,
            minStockThreshold = 2
        )

        val result = validateUseCase(medication)

        assertFalse(result.isValid)
        assertEquals(R.string.error_name_empty, result.nameError)
        assertEquals(R.string.error_dosage_empty, result.dosageError)
    }

    @Test
    fun invalidIntervalForEveryXHours_returnsError() {
        val medication = Medication(
            name = "Aspirina",
            dosage = "100 mg",
            frequencyType = FrequencyType.EVERY_X_HOURS,
            intervalHours = 0,
            startDateTime = LocalDateTime.now(),
            currentStock = 10,
            minStockThreshold = 2
        )

        val result = validateUseCase(medication)

        assertFalse(result.isValid)
        assertEquals(R.string.error_interval_invalid, result.intervalError)
    }

    @Test
    fun emptySpecificDays_returnsError() {
        val medication = Medication(
            name = "Omeprazol",
            dosage = "20 mg",
            frequencyType = FrequencyType.SPECIFIC_DAYS,
            specificDays = emptyList(),
            startDateTime = LocalDateTime.now(),
            currentStock = 10,
            minStockThreshold = 2
        )

        val result = validateUseCase(medication)

        assertFalse(result.isValid)
        assertEquals(R.string.error_specific_days_empty, result.specificDaysError)
    }

    @Test
    fun invalidCycleDays_returnsErrors() {
        val medication = Medication(
            name = "Anticonceptivo",
            dosage = "1 comprimido",
            frequencyType = FrequencyType.CYCLE,
            cycleActiveDays = 0,
            cycleRestDays = -1,
            startDateTime = LocalDateTime.now(),
            currentStock = 21,
            minStockThreshold = 5
        )

        val result = validateUseCase(medication)

        assertFalse(result.isValid)
        assertEquals(R.string.error_cycle_active_invalid, result.cycleActiveError)
        assertEquals(R.string.error_cycle_rest_invalid, result.cycleRestError)
    }
}
