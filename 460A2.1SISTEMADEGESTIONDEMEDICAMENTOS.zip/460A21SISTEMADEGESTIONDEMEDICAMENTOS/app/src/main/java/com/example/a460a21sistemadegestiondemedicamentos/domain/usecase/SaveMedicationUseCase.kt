package com.example.a460a21sistemadegestiondemedicamentos.domain.usecase

import com.example.a460a21sistemadegestiondemedicamentos.domain.alarm.AlarmScheduler
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.MedicationRepository
import javax.inject.Inject

/**
 * Caso de uso para guardar o actualizar un medicamento.
 * Valida la entrada, persiste los cambios en Room y reprograma la alarma exacta.
 */
class SaveMedicationUseCase @Inject constructor(
    private val repository: MedicationRepository,
    private val validator: ValidateMedicationUseCase,
    private val alarmScheduler: AlarmScheduler
) {

    suspend operator fun invoke(medication: Medication): Result<Long> {
        val validation = validator(medication)
        if (!validation.isValid) {
            return Result.failure(IllegalArgumentException("Validación fallida"))
        }

        val id = if (medication.id == 0L) {
            val newId = repository.insertMedication(medication)
            medication.copy(id = newId)
        } else {
            repository.updateMedication(medication)
            medication
        }

        // Si es actualización, cancelamos la alarma previa y programamos la nueva
        alarmScheduler.cancelAlarm(id.id)
        if (id.isActive) {
            alarmScheduler.scheduleNextAlarm(id)
        }

        return Result.success(id.id)
    }
}
