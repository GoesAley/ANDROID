package com.example.a460a21sistemadegestiondemedicamentos.domain.usecase

import com.example.a460a21sistemadegestiondemedicamentos.domain.model.DoseLog
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.DoseStatus
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.FrequencyType
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.DoseLogRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import java.time.LocalDateTime

class GetDoseHistoryUseCaseTest {

    private lateinit var fakeDoseLogRepository: FakeDoseLogRepository
    private lateinit var fakeMedicationRepository: FakeMedicationRepository
    private lateinit var getDoseHistoryUseCase: GetDoseHistoryUseCase

    @Before
    fun setUp() {
        fakeDoseLogRepository = FakeDoseLogRepository()
        fakeMedicationRepository = FakeMedicationRepository()
        getDoseHistoryUseCase = GetDoseHistoryUseCase(
            doseLogRepository = fakeDoseLogRepository,
            medicationRepository = fakeMedicationRepository
        )
    }

    @Test
    fun getHistory_filtersByMedicationId_isCorrect() = runBlocking {
        val med1 = Medication(id = 1, name = "Paracetamol", dosage = "500 mg", frequencyType = FrequencyType.EVERY_X_HOURS, startDateTime = LocalDateTime.now(), currentStock = 10, minStockThreshold = 2)
        val med2 = Medication(id = 2, name = "Ibuprofeno", dosage = "400 mg", frequencyType = FrequencyType.EVERY_X_HOURS, startDateTime = LocalDateTime.now(), currentStock = 10, minStockThreshold = 2)
        fakeMedicationRepository.insertedMedications.addAll(listOf(med1, med2))

        val log1 = DoseLog(id = 1, medicationId = 1, scheduledDateTime = LocalDateTime.now(), status = DoseStatus.TAKEN)
        val log2 = DoseLog(id = 2, medicationId = 2, scheduledDateTime = LocalDateTime.now(), status = DoseStatus.SKIPPED)
        fakeDoseLogRepository.logs.addAll(listOf(log1, log2))

        val result = getDoseHistoryUseCase(medicationIdFilter = 1).first()

        assertEquals(1, result.size)
        assertEquals("Paracetamol", result.first().medicationName)
    }
}

class FakeDoseLogRepository : DoseLogRepository {
    val logs = mutableListOf<DoseLog>()

    override fun getAllDoseLogs(): Flow<List<DoseLog>> = flowOf(logs)

    override fun getDoseLogsByMedication(medicationId: Long): Flow<List<DoseLog>> =
        flowOf(logs.filter { it.medicationId == medicationId })

    override fun getDoseLogsByDateRange(startDate: LocalDateTime, endDate: LocalDateTime): Flow<List<DoseLog>> =
        flowOf(logs.filter { it.scheduledDateTime in startDate..endDate })

    override fun getDoseLogsByMedicationAndDateRange(
        medicationId: Long,
        startDate: LocalDateTime,
        endDate: LocalDateTime
    ): Flow<List<DoseLog>> =
        flowOf(logs.filter { it.medicationId == medicationId && it.scheduledDateTime in startDate..endDate })

    override suspend fun getDoseLogById(id: Long): DoseLog? = logs.find { it.id == id }

    override suspend fun getDoseLogByScheduledTime(medicationId: Long, scheduledDateTime: LocalDateTime): DoseLog? =
        logs.find { it.medicationId == medicationId && it.scheduledDateTime == scheduledDateTime }

    override suspend fun recordDoseLog(doseLog: DoseLog): Long {
        val newId = (logs.size + 1).toLong()
        logs.add(doseLog.copy(id = newId))
        return newId
    }

    override suspend fun updateDoseLog(doseLog: DoseLog) {
        val idx = logs.indexOfFirst { it.id == doseLog.id }
        if (idx != -1) logs[idx] = doseLog
    }

    override suspend fun deleteLogsForMedication(medicationId: Long) {
        logs.removeIf { it.medicationId == medicationId }
    }
}
