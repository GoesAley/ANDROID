package com.example.a460a21sistemadegestiondemedicamentos.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val CleanLightColorScheme = lightColorScheme(
    primary = MedicalTealPrimary,
    onPrimary = MedicalTealOnPrimary,
    primaryContainer = MedicalTealContainer,
    onPrimaryContainer = MedicalTealOnContainer,
    secondary = MedicalMintSecondary,
    onSecondary = MedicalMintOnSecondary,
    secondaryContainer = MedicalMintContainer,
    onSecondaryContainer = MedicalMintOnContainer,
    background = MedicalLightBackground,
    onBackground = MedicalLightOnSurface,
    surface = MedicalLightSurface,
    onSurface = MedicalLightOnSurface,
    surfaceVariant = MedicalLightSurfaceVariant,
    onSurfaceVariant = MedicalLightOnSurfaceVariant,
    error = MedicalError,
    errorContainer = MedicalErrorContainer,
    onErrorContainer = MedicalOnErrorContainer
)

@Composable
fun _460A21SISTEMADEGESTIONDEMEDICAMENTOSTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CleanLightColorScheme,
        typography = Typography,
        content = content
    )
}
