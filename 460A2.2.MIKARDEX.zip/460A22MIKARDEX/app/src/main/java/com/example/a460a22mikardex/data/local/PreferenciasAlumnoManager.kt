package com.example.a460a22mikardex.data.local

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit

/**
 * Gestor de almacenamiento persistente para datos personales del alumno usando SharedPreferences.
 */
class PreferenciasAlumnoManager(context: Context) {

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREF_NAME = "pref_datos_personales"
        private const val KEY_NOMBRE = "key_nombre_completo"
        private const val KEY_NUM_CONTROL = "key_numero_control"
    }

    /**
     * Guarda el nombre completo y el número de control en SharedPreferences.
     */
    fun guardarDatosPersonales(nombre: String, numeroControl: String) {
        sharedPreferences.edit {
            putString(KEY_NOMBRE, nombre)
            putString(KEY_NUM_CONTROL, numeroControl)
        }
    }

    /**
     * Obtiene el nombre completo guardado previamente.
     */
    fun obtenerNombre(): String {
        return sharedPreferences.getString(KEY_NOMBRE, "") ?: ""
    }

    /**
     * Obtiene el número de control guardado previamente.
     */
    fun obtenerNumeroControl(): String {
        return sharedPreferences.getString(KEY_NUM_CONTROL, "") ?: ""
    }
}
