package com.example.a460a21sistemadegestiondemedicamentos.domain.repository

import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import kotlinx.coroutines.flow.Flow

interface MedicationRepository {
    fun getAllActiveMedications(): Flow<List<Medication>>
    fun getAllMedications(): Flow<List<Medication>>
    suspend fun getMedicationById(id: Long): Medication?
    fun getMedicationByIdFlow(id: Long): Flow<Medication?>
    suspend fun insertMedication(medication: Medication): Long
    suspend fun updateMedication(medication: Medication)
    suspend fun deleteMedication(id: Long)
    suspend fun addStock(id: Long, quantity: Int)
    suspend fun decrementStock(id: Long)
}
