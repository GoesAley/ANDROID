package com.example.a460a21sistemadegestiondemedicamentos.ui.medication

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.MedicationRepository
import com.example.a460a21sistemadegestiondemedicamentos.domain.usecase.DeleteMedicationUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class DetailUiEvent {
    object DeleteSuccess : DetailUiEvent()
    data class ShowSnackbar(val message: String) : DetailUiEvent()
}

@HiltViewModel
class MedicationDetailViewModel @Inject constructor(
    private val medicationRepository: MedicationRepository,
    private val deleteMedicationUseCase: DeleteMedicationUseCase,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val medicationId: Long = checkNotNull(savedStateHandle.get<Long>("medicationId"))

    val medication: StateFlow<Medication?> = medicationRepository.getMedicationByIdFlow(medicationId)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    private val _uiEvent = MutableSharedFlow<DetailUiEvent>()
    val uiEvent: SharedFlow<DetailUiEvent> = _uiEvent.asSharedFlow()

    fun deleteMedication() {
        viewModelScope.launch {
            try {
                deleteMedicationUseCase(medicationId)
                _uiEvent.emit(DetailUiEvent.DeleteSuccess)
            } catch (e: Exception) {
                _uiEvent.emit(DetailUiEvent.ShowSnackbar("Error al eliminar el tratamiento"))
            }
        }
    }
}
