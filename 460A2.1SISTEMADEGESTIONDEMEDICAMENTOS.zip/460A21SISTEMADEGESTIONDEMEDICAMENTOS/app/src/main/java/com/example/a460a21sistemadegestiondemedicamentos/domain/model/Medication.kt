package com.example.a460a21sistemadegestiondemedicamentos.domain.model

import java.time.DayOfWeek
import java.time.LocalDateTime

/**
 * Modelo de dominio para un medicamento / tratamiento.
 */
data class Medication(
    val id: Long = 0,
    val name: String,
    val dosage: String,
    val frequencyType: FrequencyType,
    val intervalHours: Int? = null,
    val specificDays: List<DayOfWeek> = emptyList(),
    val cycleActiveDays: Int? = null,
    val cycleRestDays: Int? = null,
    val startDateTime: LocalDateTime,
    val currentStock: Int,
    val minStockThreshold: Int,
    val isActive: Boolean = true
)
