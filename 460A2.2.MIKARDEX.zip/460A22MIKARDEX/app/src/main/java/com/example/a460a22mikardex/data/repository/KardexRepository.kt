package com.example.a460a22mikardex.data.repository

import com.example.a460a22mikardex.data.local.MateriaDao
import com.example.a460a22mikardex.data.local.MateriaKardex
import com.example.a460a22mikardex.data.local.PreferenciasAlumnoManager
import kotlinx.coroutines.flow.Flow

/**
 * Repositorio que unifica el acceso a datos (Room Database y SharedPreferences).
 */
class KardexRepository(
    private val materiaDao: MateriaDao,
    private val preferenciasManager: PreferenciasAlumnoManager
) {

    // Room operations
    val todasLasMaterias: Flow<List<MateriaKardex>> = materiaDao.obtenerTodas()

    suspend fun insertarMateria(materia: MateriaKardex) {
        materiaDao.insertar(materia)
    }

    suspend fun eliminarMateria(materia: MateriaKardex) {
        materiaDao.eliminar(materia)
    }

    // SharedPreferences operations
    fun guardarDatosPersonales(nombre: String, numeroControl: String) {
        preferenciasManager.guardarDatosPersonales(nombre, numeroControl)
    }

    fun obtenerNombreAlumno(): String {
        return preferenciasManager.obtenerNombre()
    }

    fun obtenerNumeroControlAlumno(): String {
        return preferenciasManager.obtenerNumeroControl()
    }
}
