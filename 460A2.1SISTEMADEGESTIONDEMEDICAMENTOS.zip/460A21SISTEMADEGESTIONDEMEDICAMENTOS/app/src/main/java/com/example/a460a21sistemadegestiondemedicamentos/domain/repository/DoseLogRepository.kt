package com.example.a460a21sistemadegestiondemedicamentos.domain.repository

import com.example.a460a21sistemadegestiondemedicamentos.domain.model.DoseLog
import kotlinx.coroutines.flow.Flow
import java.time.LocalDateTime

interface DoseLogRepository {
    fun getAllDoseLogs(): Flow<List<DoseLog>>
    fun getDoseLogsByMedication(medicationId: Long): Flow<List<DoseLog>>
    fun getDoseLogsByDateRange(startDate: LocalDateTime, endDate: LocalDateTime): Flow<List<DoseLog>>
    fun getDoseLogsByMedicationAndDateRange(medicationId: Long, startDate: LocalDateTime, endDate: LocalDateTime): Flow<List<DoseLog>>
    suspend fun getDoseLogById(id: Long): DoseLog?
    suspend fun getDoseLogByScheduledTime(medicationId: Long, scheduledDateTime: LocalDateTime): DoseLog?
    suspend fun recordDoseLog(doseLog: DoseLog): Long
    suspend fun updateDoseLog(doseLog: DoseLog)
    suspend fun deleteLogsForMedication(medicationId: Long)
}
