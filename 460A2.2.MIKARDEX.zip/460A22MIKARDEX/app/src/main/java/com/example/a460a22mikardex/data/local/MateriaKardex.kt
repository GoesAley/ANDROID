package com.example.a460a22mikardex.data.local

import androidx.room.Entity
import androidx.room.Ignore
import androidx.room.PrimaryKey
import java.util.Locale

enum class EstatusMateria {
    ACREDITADA,          // Azul (Pasó la materia >= 70.0)
    VA_A_REPETICION,     // Amarillo (Reprobó Normal < 70.0 -> Va a Repetición)
    VA_A_ESPECIAL,       // Anaranjado (Reprobó Repetición < 70.0 -> Va a Curso Especial)
    SIN_OPORTUNIDAD      // Rojo (Reprobó Especial o Verano < 70.0 -> Sin Oportunidad)
}

/**
 * Entidad que representa una materia registrada en la base de datos de Room.
 * Tabla única: materias_kardex
 */
@Entity(tableName = "materias_kardex")
data class MateriaKardex(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val nombre: String,
    val semestre: Int,
    val normal: Double? = null,
    val repeticion: Double? = null,
    val especial: Double? = null,
    val verano: Double? = null
) {
    /**
     * Obtiene la calificación final registrada según el curso o periodo presentado.
     */
    @get:Ignore
    val calificacionFinal: Double?
        get() = verano ?: especial ?: repeticion ?: normal

    /**
     * Retorna el tipo de curso u oportunidad presentada.
     */
    @get:Ignore
    val oportunidadCursada: String
        get() = when {
            verano != null -> "Verano"
            especial != null -> "Especial"
            repeticion != null -> "Repetición"
            else -> "Normal"
        }

    /**
     * Determina si la materia fue acreditada (calificación final >= 70.0).
     */
    @get:Ignore
    val estaAcreditada: Boolean
        get() {
            val nota = calificacionFinal ?: return false
            return nota >= 70.0
        }

    /**
     * Retorna la calificación formateada (ej. "85.00") si fue acreditada (>= 70.0),
     * o "N/A" si no fue acreditada (< 70.0 o nula).
     */
    @get:Ignore
    val calificacionMostrar: String
        get() {
            val nota = calificacionFinal
            return if (nota != null && nota >= 70.0) {
                String.format(Locale.US, "%.2f", nota)
            } else {
                "N/A"
            }
        }

    /**
     * Retorna el estatus para asignar los colores de resaltado:
     * - ACREDITADA (Azul): Pasó en cualquier curso (Normal, Repetición, Especial, Verano)
     * - VA_A_REPETICION (Amarillo): Reprobó en Normal
     * - VA_A_ESPECIAL (Anaranjado): Reprobó en Repetición
     * - SIN_OPORTUNIDAD (Rojo): Reprobó en Especial o Verano
     */
    @get:Ignore
    val estatus: EstatusMateria
        get() {
            val nota = calificacionFinal
            if (nota != null && nota >= 70.0) return EstatusMateria.ACREDITADA
            return when (oportunidadCursada) {
                "Normal" -> EstatusMateria.VA_A_REPETICION
                "Repetición" -> EstatusMateria.VA_A_ESPECIAL
                else -> EstatusMateria.SIN_OPORTUNIDAD
            }
        }
}
