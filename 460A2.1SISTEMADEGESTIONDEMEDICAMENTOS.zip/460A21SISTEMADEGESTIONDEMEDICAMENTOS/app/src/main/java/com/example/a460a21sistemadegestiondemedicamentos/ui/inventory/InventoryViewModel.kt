package com.example.a460a21sistemadegestiondemedicamentos.ui.inventory

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.MedicationRepository
import com.example.a460a21sistemadegestiondemedicamentos.domain.usecase.RefillStockUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class InventoryUiEvent {
    data class ShowSnackbar(val message: String) : InventoryUiEvent()
}

@HiltViewModel
class InventoryViewModel @Inject constructor(
    private val medicationRepository: MedicationRepository,
    private val refillStockUseCase: RefillStockUseCase
) : ViewModel() {

    val medications: StateFlow<List<Medication>> = medicationRepository.getAllActiveMedications()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _uiEvent = MutableSharedFlow<InventoryUiEvent>()
    val uiEvent: SharedFlow<InventoryUiEvent> = _uiEvent.asSharedFlow()

    fun refillStock(medicationId: Long, quantity: Int) {
        viewModelScope.launch {
            val result = refillStockUseCase(medicationId, quantity)
            if (result.isSuccess) {
                _uiEvent.emit(InventoryUiEvent.ShowSnackbar("Stock recargado correctamente"))
            } else {
                _uiEvent.emit(InventoryUiEvent.ShowSnackbar("Ingresa una cantidad válida"))
            }
        }
    }
}
