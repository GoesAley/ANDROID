package com.example.a460a21sistemadegestiondemedicamentos.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta de tonos claros limpios e higiénicos para app médica (Teal / Verde Azulado Médico)
val MedicalTealPrimary = Color(0xFF006A67)
val MedicalTealOnPrimary = Color(0xFFFFFFFF)
val MedicalTealContainer = Color(0xFF9CF1EE)
val MedicalTealOnContainer = Color(0xFF00201F)

val MedicalMintSecondary = Color(0xFF4A6362)
val MedicalMintOnSecondary = Color(0xFFFFFFFF)
val MedicalMintContainer = Color(0xFFCCE8E6)
val MedicalMintOnContainer = Color(0xFF051F1E)

val MedicalLightBackground = Color(0xFFF4FBF9)
val MedicalLightSurface = Color(0xFFFFFFFF)
val MedicalLightSurfaceVariant = Color(0xFFE0ECEB)
val MedicalLightOnSurface = Color(0xFF161D1D)
val MedicalLightOnSurfaceVariant = Color(0xFF3F4948)

val MedicalError = Color(0xFFBA1A1A)
val MedicalErrorContainer = Color(0xFFFFDAD6)
val MedicalOnErrorContainer = Color(0xFF410002)
