package com.example.a460a21sistemadegestiondemedicamentos.domain.model

// Módulo de cuidador removido según especificación
