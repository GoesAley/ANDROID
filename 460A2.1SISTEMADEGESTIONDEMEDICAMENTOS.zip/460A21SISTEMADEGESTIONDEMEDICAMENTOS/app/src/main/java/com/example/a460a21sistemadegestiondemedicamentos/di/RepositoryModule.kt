package com.example.a460a21sistemadegestiondemedicamentos.di

import com.example.a460a21sistemadegestiondemedicamentos.data.repository.DoseLogRepositoryImpl
import com.example.a460a21sistemadegestiondemedicamentos.data.repository.MedicationRepositoryImpl
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.DoseLogRepository
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.MedicationRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindMedicationRepository(
        impl: MedicationRepositoryImpl
    ): MedicationRepository

    @Binds
    @Singleton
    abstract fun bindDoseLogRepository(
        impl: DoseLogRepositoryImpl
    ): DoseLogRepository
}
