package com.example.a460a21sistemadegestiondemedicamentos.data.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.a460a21sistemadegestiondemedicamentos.domain.alarm.AlarmScheduler
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.DoseLog
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.DoseStatus
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.DoseLogRepository
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.MedicationRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import javax.inject.Inject

@AndroidEntryPoint
class AlarmReceiver : BroadcastReceiver() {

    @Inject
    lateinit var notificationHelper: NotificationHelper

    @Inject
    lateinit var medicationRepository: MedicationRepository

    @Inject
    lateinit var doseLogRepository: DoseLogRepository

    @Inject
    lateinit var alarmScheduler: AlarmScheduler

    override fun onReceive(context: Context, intent: Intent) {
        val medicationId = intent.getLongExtra(NotificationHelper.EXTRA_MEDICATION_ID, -1L)
        if (medicationId == -1L) return

        val action = intent.action
        val isPostponed = intent.getBooleanExtra(NotificationHelper.EXTRA_IS_POSTPONED, false)

        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val medication = medicationRepository.getMedicationById(medicationId)

                when (action) {
                    NotificationHelper.ACTION_TAKEN -> {
                        if (medication != null) {
                            val scheduledIso = intent.getStringExtra(NotificationHelper.EXTRA_SCHEDULED_TIME)
                            val scheduledTime = scheduledIso?.let { LocalDateTime.parse(it) } ?: LocalDateTime.now()

                            // 1. Registrar toma en DoseLog
                            doseLogRepository.recordDoseLog(
                                DoseLog(
                                    medicationId = medicationId,
                                    scheduledDateTime = scheduledTime,
                                    actionDateTime = LocalDateTime.now(),
                                    status = DoseStatus.TAKEN
                                )
                            )

                            // 2. Descontar 1 del stock
                            medicationRepository.decrementStock(medicationId)

                            // 3. Cancelar notificación e ir a la siguiente alarma
                            notificationHelper.dismissNotification(medicationId)
                            val updatedMedication = medicationRepository.getMedicationById(medicationId)
                            if (updatedMedication != null && updatedMedication.isActive) {
                                alarmScheduler.scheduleNextAlarm(updatedMedication)
                            }
                        }
                    }

                    NotificationHelper.ACTION_POSTPONE -> {
                        notificationHelper.dismissNotification(medicationId)
                        if (medication != null) {
                            val scheduledIso = intent.getStringExtra(NotificationHelper.EXTRA_SCHEDULED_TIME)
                            val scheduledTime = scheduledIso?.let { LocalDateTime.parse(it) } ?: LocalDateTime.now()

                            // 1. Registrar evento POSTPONED en DoseLog
                            doseLogRepository.recordDoseLog(
                                DoseLog(
                                    medicationId = medicationId,
                                    scheduledDateTime = scheduledTime,
                                    actionDateTime = LocalDateTime.now(),
                                    status = DoseStatus.POSTPONED
                                )
                            )

                            // 2. Reprogramar para 15 minutos después
                            val postponedMedication = medication.copy(
                                startDateTime = LocalDateTime.now().plusMinutes(15)
                            )
                            alarmScheduler.scheduleNextAlarm(postponedMedication)

                            // 3. Mostrar notificación emergente de confirmación
                            notificationHelper.showPostponedConfirmationNotification(medication, 15)
                        }
                    }

                    else -> { // ACTION_TRIGGER_NOTIFICATION
                        if (medication != null && medication.isActive) {
                            notificationHelper.showMedicationNotification(
                                medication = medication,
                                scheduledTimeIso = LocalDateTime.now().toString(),
                                isPostponed = isPostponed
                            )
                        }
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
