package com.example.a460a22mikardex.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object (DAO) para operaciones CRUD sobre la tabla materias_kardex.
 */
@Dao
interface MateriaDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertar(materia: MateriaKardex)

    @Delete
    suspend fun eliminar(materia: MateriaKardex)

    @Query("SELECT * FROM materias_kardex ORDER BY semestre ASC, nombre ASC")
    fun obtenerTodas(): Flow<List<MateriaKardex>>
}
