package com.example.a460a21sistemadegestiondemedicamentos.domain.alarm

import com.example.a460a21sistemadegestiondemedicamentos.domain.model.FrequencyType
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import java.time.DayOfWeek
import java.time.LocalDateTime

class DoseCalculatorTest {

    private lateinit var doseCalculator: DoseCalculator

    @Before
    fun setUp() {
        doseCalculator = DoseCalculator()
    }

    @Test
    fun calculateNextDose_every8Hours_isCorrect() {
        val start = LocalDateTime.of(2026, 10, 6, 8, 0)
        val medication = Medication(
            id = 1,
            name = "Paracetamol",
            dosage = "500 mg",
            frequencyType = FrequencyType.EVERY_X_HOURS,
            intervalHours = 8,
            startDateTime = start,
            currentStock = 10,
            minStockThreshold = 2
        )

        val reference = LocalDateTime.of(2026, 10, 6, 8, 30)
        val nextDose = doseCalculator.calculateNextDose(medication, reference)

        assertEquals(LocalDateTime.of(2026, 10, 6, 16, 0), nextDose)
    }

    @Test
    fun calculateNextDose_specificDays_isCorrect() {
        // Lunes 5 de Octubre 2026 a las 09:00 AM
        val start = LocalDateTime.of(2026, 10, 5, 9, 0)
        val medication = Medication(
            id = 2,
            name = "Vitamina C",
            dosage = "1 pastilla",
            frequencyType = FrequencyType.SPECIFIC_DAYS,
            specificDays = listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY),
            startDateTime = start,
            currentStock = 30,
            minStockThreshold = 5
        )

        // Referencia: Lunes 5 a las 10:00 AM -> La siguiente debe ser Miércoles 7 a las 09:00 AM
        val reference = LocalDateTime.of(2026, 10, 5, 10, 0)
        val nextDose = doseCalculator.calculateNextDose(medication, reference)

        assertEquals(LocalDateTime.of(2026, 10, 7, 9, 0), nextDose)
    }

    @Test
    fun calculateNextDose_alternateDays_isCorrect() {
        // Martes 6 de Octubre 2026 a las 10:00 AM
        val start = LocalDateTime.of(2026, 10, 6, 10, 0)
        val medication = Medication(
            id = 3,
            name = "Omeprazol",
            dosage = "20 mg",
            frequencyType = FrequencyType.ALTERNATE_DAYS,
            startDateTime = start,
            currentStock = 10,
            minStockThreshold = 2
        )

        // Referencia: Martes 6 a las 11:00 AM -> La siguiente debe ser Jueves 8 a las 10:00 AM
        val reference = LocalDateTime.of(2026, 10, 6, 11, 0)
        val nextDose = doseCalculator.calculateNextDose(medication, reference)

        assertEquals(LocalDateTime.of(2026, 10, 8, 10, 0), nextDose)
    }

    @Test
    fun calculateNextDose_cycleRestDays_skipsRestPeriod() {
        // Inicio: 1 de Octubre con ciclo 5 días activo / 2 días descanso
        val start = LocalDateTime.of(2026, 10, 1, 8, 0)
        val medication = Medication(
            id = 4,
            name = "Tratamiento Cíclico",
            dosage = "1 pastilla",
            frequencyType = FrequencyType.CYCLE,
            cycleActiveDays = 5,
            cycleRestDays = 2,
            startDateTime = start,
            currentStock = 20,
            minStockThreshold = 5
        )

        // Días activos: 1, 2, 3, 4, 5 de Octubre. Días descanso: 6, 7 de Octubre.
        // Referencia: 5 de Octubre a las 09:00 AM (ya pasó la toma del 5)
        // La siguiente debe ser el 8 de Octubre a las 08:00 AM (primer día activo del nuevo ciclo).
        val reference = LocalDateTime.of(2026, 10, 5, 9, 0)
        val nextDose = doseCalculator.calculateNextDose(medication, reference)

        assertEquals(LocalDateTime.of(2026, 10, 8, 8, 0), nextDose)
    }
}
