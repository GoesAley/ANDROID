package com.example.a460a21sistemadegestiondemedicamentos.domain.usecase

import com.example.a460a21sistemadegestiondemedicamentos.domain.model.DoseLog
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.DoseLogRepository
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.MedicationRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import java.time.LocalDateTime
import javax.inject.Inject

data class DoseHistoryDisplayItem(
    val doseLog: DoseLog,
    val medicationName: String,
    val dosage: String
)

/**
 * Caso de uso para obtener el historial cronológico de tomas con filtros opcionales.
 */
class GetDoseHistoryUseCase @Inject constructor(
    private val doseLogRepository: DoseLogRepository,
    private val medicationRepository: MedicationRepository
) {

    operator fun invoke(
        medicationIdFilter: Long? = null,
        startDateFilter: LocalDateTime? = null,
        endDateFilter: LocalDateTime? = null
    ): Flow<List<DoseHistoryDisplayItem>> {
        val logsFlow = if (medicationIdFilter != null && startDateFilter != null && endDateFilter != null) {
            doseLogRepository.getDoseLogsByMedicationAndDateRange(medicationIdFilter, startDateFilter, endDateFilter)
        } else if (medicationIdFilter != null) {
            doseLogRepository.getDoseLogsByMedication(medicationIdFilter)
        } else if (startDateFilter != null && endDateFilter != null) {
            doseLogRepository.getDoseLogsByDateRange(startDateFilter, endDateFilter)
        } else {
            doseLogRepository.getAllDoseLogs()
        }

        val medicationsFlow = medicationRepository.getAllMedications()

        return combine(logsFlow, medicationsFlow) { logs, medications ->
            val medMap = medications.associateBy { it.id }

            logs.map { log ->
                val med = medMap[log.medicationId]
                DoseHistoryDisplayItem(
                    doseLog = log,
                    medicationName = med?.name ?: "Medicamento Eliminado",
                    dosage = med?.dosage ?: ""
                )
            }.sortedByDescending { it.doseLog.scheduledDateTime }
        }
    }
}
