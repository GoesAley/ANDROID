package com.example.a460a21sistemadegestiondemedicamentos.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.a460a21sistemadegestiondemedicamentos.ui.calendar.WeeklyScheduleScreen
import com.example.a460a21sistemadegestiondemedicamentos.ui.history.DoseHistoryScreen
import com.example.a460a21sistemadegestiondemedicamentos.ui.inventory.InventoryScreen
import com.example.a460a21sistemadegestiondemedicamentos.ui.medication.AddEditMedicationScreen
import com.example.a460a21sistemadegestiondemedicamentos.ui.medication.MedicationDetailScreen
import com.example.a460a21sistemadegestiondemedicamentos.ui.medication.MedicationListScreen

object Screen {
    const val MEDICATION_LIST = "medication_list"
    const val ADD_EDIT_MEDICATION = "add_edit_medication?medicationId={medicationId}"
    const val MEDICATION_DETAIL = "medication_detail/{medicationId}"
    const val WEEKLY_SCHEDULE = "weekly_schedule"
    const val DOSE_HISTORY = "dose_history"
    const val INVENTORY = "inventory"

    fun createAddEditRoute(medicationId: Long? = null): String {
        return if (medicationId != null) "add_edit_medication?medicationId=$medicationId"
        else "add_edit_medication"
    }

    fun createDetailRoute(medicationId: Long): String {
        return "medication_detail/$medicationId"
    }
}

@Composable
fun AppNavigation(
    navController: NavHostController = rememberNavController()
) {
    NavHost(
        navController = navController,
        startDestination = Screen.MEDICATION_LIST
    ) {
        composable(Screen.MEDICATION_LIST) { entry ->
            val resultMessage = entry.savedStateHandle.get<String>("result_message")
            MedicationListScreen(
                resultMessage = resultMessage,
                onResultMessageConsumed = {
                    entry.savedStateHandle.remove<String>("result_message")
                },
                onNavigateToAdd = {
                    navController.navigate(Screen.createAddEditRoute())
                },
                onNavigateToEdit = { id ->
                    navController.navigate(Screen.createAddEditRoute(id))
                },
                onNavigateToDetail = { id ->
                    navController.navigate(Screen.createDetailRoute(id))
                },
                onNavigateToWeeklySchedule = {
                    navController.navigate(Screen.WEEKLY_SCHEDULE)
                },
                onNavigateToHistory = {
                    navController.navigate(Screen.DOSE_HISTORY)
                },
                onNavigateToInventory = {
                    navController.navigate(Screen.INVENTORY)
                }
            )
        }

        composable(Screen.WEEKLY_SCHEDULE) {
            WeeklyScheduleScreen(
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(Screen.DOSE_HISTORY) {
            DoseHistoryScreen(
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(Screen.INVENTORY) {
            InventoryScreen(
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(
            route = Screen.ADD_EDIT_MEDICATION,
            arguments = listOf(
                navArgument("medicationId") {
                    type = NavType.LongType
                    defaultValue = -1L
                }
            )
        ) {
            AddEditMedicationScreen(
                onNavigateBackWithResult = { message ->
                    navController.previousBackStackEntry
                        ?.savedStateHandle
                        ?.set("result_message", message)
                    navController.popBackStack()
                },
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(
            route = Screen.MEDICATION_DETAIL,
            arguments = listOf(
                navArgument("medicationId") {
                    type = NavType.LongType
                }
            )
        ) {
            MedicationDetailScreen(
                onNavigateBack = {
                    navController.popBackStack()
                },
                onNavigateToEdit = { id ->
                    navController.navigate(Screen.createAddEditRoute(id))
                }
            )
        }
    }
}
