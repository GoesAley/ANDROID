package com.example.a460a21sistemadegestiondemedicamentos.domain.model

/**
 * Estado de cada dosis programada.
 */
enum class DoseStatus {
    PENDING,    // Pendiente
    TAKEN,      // Tomada
    SKIPPED,    // Omitida
    POSTPONED   // Pospuesta
}
