package com.example.a460a21sistemadegestiondemedicamentos.domain.usecase

import com.example.a460a21sistemadegestiondemedicamentos.domain.alarm.AlarmScheduler
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.FrequencyType
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.MedicationRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.time.LocalDateTime

class SaveMedicationUseCaseTest {

    private lateinit var fakeRepository: FakeMedicationRepository
    private lateinit var fakeAlarmScheduler: FakeAlarmScheduler
    private lateinit var saveUseCase: SaveMedicationUseCase

    @Before
    fun setUp() {
        fakeRepository = FakeMedicationRepository()
        fakeAlarmScheduler = FakeAlarmScheduler()
        saveUseCase = SaveMedicationUseCase(
            repository = fakeRepository,
            validator = ValidateMedicationUseCase(),
            alarmScheduler = fakeAlarmScheduler
        )
    }

    @Test
    fun saveValidMedication_insertsAndSchedulesAlarm() = runBlocking {
        val medication = Medication(
            name = "Amoxicilina",
            dosage = "500 mg",
            frequencyType = FrequencyType.EVERY_X_HOURS,
            intervalHours = 8,
            startDateTime = LocalDateTime.now(),
            currentStock = 15,
            minStockThreshold = 3
        )

        val result = saveUseCase(medication)

        assertTrue(result.isSuccess)
        assertEquals(1L, result.getOrNull())
        assertEquals(1, fakeRepository.insertedMedications.size)
        assertEquals(1, fakeAlarmScheduler.scheduledMedications.size)
    }
}

class FakeMedicationRepository : MedicationRepository {
    val insertedMedications = mutableListOf<Medication>()

    override fun getAllActiveMedications(): Flow<List<Medication>> = flowOf(insertedMedications)
    override fun getAllMedications(): Flow<List<Medication>> = flowOf(insertedMedications)
    override suspend fun getMedicationById(id: Long): Medication? = insertedMedications.find { it.id == id }
    override fun getMedicationByIdFlow(id: Long): Flow<Medication?> = flowOf(insertedMedications.find { it.id == id })

    override suspend fun insertMedication(medication: Medication): Long {
        val newId = (insertedMedications.size + 1).toLong()
        insertedMedications.add(medication.copy(id = newId))
        return newId
    }

    override suspend fun updateMedication(medication: Medication) {
        val index = insertedMedications.indexOfFirst { it.id == medication.id }
        if (index != -1) {
            insertedMedications[index] = medication
        }
    }

    override suspend fun deleteMedication(id: Long) {
        insertedMedications.removeIf { it.id == id }
    }

    override suspend fun addStock(id: Long, quantity: Int) {
        val index = insertedMedications.indexOfFirst { it.id == id }
        if (index != -1) {
            val current = insertedMedications[index]
            insertedMedications[index] = current.copy(currentStock = current.currentStock + quantity)
        }
    }

    override suspend fun decrementStock(id: Long) {
        val index = insertedMedications.indexOfFirst { it.id == id }
        if (index != -1) {
            val current = insertedMedications[index]
            insertedMedications[index] = current.copy(currentStock = maxOf(0, current.currentStock - 1))
        }
    }
}

class FakeAlarmScheduler : AlarmScheduler {
    val scheduledMedications = mutableListOf<Medication>()
    val canceledIds = mutableListOf<Long>()

    override fun scheduleNextAlarm(medication: Medication) {
        scheduledMedications.add(medication)
    }

    override fun cancelAlarm(medicationId: Long) {
        canceledIds.add(medicationId)
    }
}
