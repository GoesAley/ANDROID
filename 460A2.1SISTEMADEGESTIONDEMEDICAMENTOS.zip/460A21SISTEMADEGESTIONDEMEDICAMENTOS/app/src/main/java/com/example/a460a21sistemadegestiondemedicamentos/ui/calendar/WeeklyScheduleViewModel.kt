package com.example.a460a21sistemadegestiondemedicamentos.ui.calendar

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.a460a21sistemadegestiondemedicamentos.domain.alarm.DoseCalculator
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.MedicationRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import javax.inject.Inject

data class ScheduledDoseItem(
    val medication: Medication,
    val scheduledDateTime: LocalDateTime
)

data class WeeklyScheduleUiState(
    val selectedDate: LocalDate = LocalDate.now(),
    val weekDays: List<LocalDate> = emptyList(),
    val scheduledDosesForSelectedDate: List<ScheduledDoseItem> = emptyList(),
    val isLoading: Boolean = false
)

@HiltViewModel
class WeeklyScheduleViewModel @Inject constructor(
    private val medicationRepository: MedicationRepository,
    private val doseCalculator: DoseCalculator
) : ViewModel() {

    private val _selectedDate = MutableStateFlow(LocalDate.now())
    val selectedDate: StateFlow<LocalDate> = _selectedDate.asStateFlow()

    private val currentWeekMonday: LocalDate = LocalDate.now().with(DayOfWeek.MONDAY)
    private val weekDaysList: List<LocalDate> = (0..6).map { currentWeekMonday.plusDays(it.toLong()) }

    val uiState: StateFlow<WeeklyScheduleUiState> = combine(
        _selectedDate,
        medicationRepository.getAllActiveMedications()
    ) { date, medications ->
        val startOfDay = LocalDateTime.of(date, LocalTime.MIN)
        val endOfDay = LocalDateTime.of(date, LocalTime.MAX)

        val scheduledItems = mutableListOf<ScheduledDoseItem>()

        medications.forEach { medication ->
            val doses = doseCalculator.previewScheduleForDateRange(
                medication = medication,
                rangeStart = startOfDay,
                rangeEnd = endOfDay
            )
            doses.forEach { doseDateTime ->
                scheduledItems.add(ScheduledDoseItem(medication, doseDateTime))
            }
        }

        WeeklyScheduleUiState(
            selectedDate = date,
            weekDays = weekDaysList,
            scheduledDosesForSelectedDate = scheduledItems.sortedBy { it.scheduledDateTime }
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = WeeklyScheduleUiState(weekDays = weekDaysList)
    )

    fun onDateSelected(date: LocalDate) {
        _selectedDate.value = date
    }
}
