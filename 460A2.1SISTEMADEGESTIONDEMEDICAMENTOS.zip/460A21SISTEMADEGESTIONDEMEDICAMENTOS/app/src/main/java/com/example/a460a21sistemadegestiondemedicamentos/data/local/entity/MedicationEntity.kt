package com.example.a460a21sistemadegestiondemedicamentos.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "medications")
data class MedicationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val dosage: String,
    val frequencyType: String,
    val intervalHours: Int?,
    val specificDays: String, // Comma-separated DayOfWeek names, e.g. "MONDAY,WEDNESDAY"
    val cycleActiveDays: Int?,
    val cycleRestDays: Int?,
    val startDateTime: String, // ISO-8601 LocalDateTime String
    val currentStock: Int,
    val minStockThreshold: Int,
    val isActive: Boolean
)
