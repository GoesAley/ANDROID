package com.example.a460a21sistemadegestiondemedicamentos.data.repository

import com.example.a460a21sistemadegestiondemedicamentos.data.local.dao.MedicationDao
import com.example.a460a21sistemadegestiondemedicamentos.data.mapper.toDomain
import com.example.a460a21sistemadegestiondemedicamentos.data.mapper.toEntity
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.MedicationRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MedicationRepositoryImpl @Inject constructor(
    private val medicationDao: MedicationDao
) : MedicationRepository {

    override fun getAllActiveMedications(): Flow<List<Medication>> {
        return medicationDao.getAllActiveMedications().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override fun getAllMedications(): Flow<List<Medication>> {
        return medicationDao.getAllMedications().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override suspend fun getMedicationById(id: Long): Medication? {
        return medicationDao.getMedicationById(id)?.toDomain()
    }

    override fun getMedicationByIdFlow(id: Long): Flow<Medication?> {
        return medicationDao.getMedicationByIdFlow(id).map { it?.toDomain() }
    }

    override suspend fun insertMedication(medication: Medication): Long {
        return medicationDao.insertMedication(medication.toEntity())
    }

    override suspend fun updateMedication(medication: Medication) {
        medicationDao.updateMedication(medication.toEntity())
    }

    override suspend fun deleteMedication(id: Long) {
        medicationDao.deleteMedicationById(id)
    }

    override suspend fun addStock(id: Long, quantity: Int) {
        medicationDao.addStock(id, quantity)
    }

    override suspend fun decrementStock(id: Long) {
        medicationDao.decrementStock(id)
    }
}
