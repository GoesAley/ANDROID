package com.example.a460a21sistemadegestiondemedicamentos.domain.usecase

import com.example.a460a21sistemadegestiondemedicamentos.R
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.FrequencyType
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import javax.inject.Inject

/**
 * Resultado de validación con identificadores de recurso de cadenas de error para la UI.
 */
data class MedicationValidationResult(
    val nameError: Int? = null,
    val dosageError: Int? = null,
    val intervalError: Int? = null,
    val specificDaysError: Int? = null,
    val cycleActiveError: Int? = null,
    val cycleRestError: Int? = null,
    val stockError: Int? = null,
    val minThresholdError: Int? = null
) {
    val isValid: Boolean
        get() = nameError == null &&
                dosageError == null &&
                intervalError == null &&
                specificDaysError == null &&
                cycleActiveError == null &&
                cycleRestError == null &&
                stockError == null &&
                minThresholdError == null
}

/**
 * Caso de uso para validar los campos obligatorios y reglas de negocio del formulario de medicamentos.
 */
class ValidateMedicationUseCase @Inject constructor() {

    operator fun invoke(medication: Medication): MedicationValidationResult {
        var nameError: Int? = null
        var dosageError: Int? = null
        var intervalError: Int? = null
        var specificDaysError: Int? = null
        var cycleActiveError: Int? = null
        var cycleRestError: Int? = null
        var stockError: Int? = null
        var minThresholdError: Int? = null

        if (medication.name.isBlank()) {
            nameError = R.string.error_name_empty
        }

        if (medication.dosage.isBlank()) {
            dosageError = R.string.error_dosage_empty
        }

        when (medication.frequencyType) {
            FrequencyType.EVERY_X_HOURS -> {
                if (medication.intervalHours == null || medication.intervalHours <= 0) {
                    intervalError = R.string.error_interval_invalid
                }
            }
            FrequencyType.SPECIFIC_DAYS -> {
                if (medication.specificDays.isEmpty()) {
                    specificDaysError = R.string.error_specific_days_empty
                }
            }
            FrequencyType.ALTERNATE_DAYS -> {
                // No se requieren campos adicionales obligatorios
            }
            FrequencyType.CYCLE -> {
                if (medication.cycleActiveDays == null || medication.cycleActiveDays <= 0) {
                    cycleActiveError = R.string.error_cycle_active_invalid
                }
                if (medication.cycleRestDays == null || medication.cycleRestDays <= 0) {
                    cycleRestError = R.string.error_cycle_rest_invalid
                }
            }
        }

        if (medication.currentStock < 0) {
            stockError = R.string.error_stock_invalid
        }

        if (medication.minStockThreshold < 0) {
            minThresholdError = R.string.error_threshold_invalid
        }

        return MedicationValidationResult(
            nameError = nameError,
            dosageError = dosageError,
            intervalError = intervalError,
            specificDaysError = specificDaysError,
            cycleActiveError = cycleActiveError,
            cycleRestError = cycleRestError,
            stockError = stockError,
            minThresholdError = minThresholdError
        )
    }
}
