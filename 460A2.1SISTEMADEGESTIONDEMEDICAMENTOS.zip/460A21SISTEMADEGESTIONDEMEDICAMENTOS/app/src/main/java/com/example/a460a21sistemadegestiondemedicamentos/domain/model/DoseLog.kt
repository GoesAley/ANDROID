package com.example.a460a21sistemadegestiondemedicamentos.domain.model

import java.time.LocalDateTime

/**
 * Modelo de dominio para el registro de tomas individuales.
 */
data class DoseLog(
    val id: Long = 0,
    val medicationId: Long,
    val scheduledDateTime: LocalDateTime,
    val actionDateTime: LocalDateTime? = null,
    val status: DoseStatus = DoseStatus.PENDING
)
