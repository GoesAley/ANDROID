package com.example.a460a21sistemadegestiondemedicamentos.ui.medication

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.FrequencyType
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.MedicationRepository
import com.example.a460a21sistemadegestiondemedicamentos.domain.usecase.MedicationValidationResult
import com.example.a460a21sistemadegestiondemedicamentos.domain.usecase.SaveMedicationUseCase
import com.example.a460a21sistemadegestiondemedicamentos.domain.usecase.ValidateMedicationUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDateTime
import javax.inject.Inject

data class AddEditFormState(
    val medicationId: Long = 0,
    val name: String = "",
    val dosage: String = "",
    val frequencyType: FrequencyType = FrequencyType.EVERY_X_HOURS,
    val intervalHours: String = "8",
    val specificDays: Set<DayOfWeek> = emptySet(),
    val cycleActiveDays: String = "21",
    val cycleRestDays: String = "7",
    val startDateTime: LocalDateTime = LocalDateTime.now().withSecond(0).withNano(0),
    val currentStock: String = "30",
    val minStockThreshold: String = "5",
    val validationResult: MedicationValidationResult = MedicationValidationResult(),
    val isSaving: Boolean = false,
    val isEditMode: Boolean = false
)

sealed class FormUiEvent {
    data class SaveSuccess(val isEditMode: Boolean) : FormUiEvent()
    data class ShowError(val message: String) : FormUiEvent()
}

@HiltViewModel
class AddEditMedicationViewModel @Inject constructor(
    private val saveMedicationUseCase: SaveMedicationUseCase,
    private val validateMedicationUseCase: ValidateMedicationUseCase,
    private val medicationRepository: MedicationRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val _formState = MutableStateFlow(AddEditFormState())
    val formState: StateFlow<AddEditFormState> = _formState.asStateFlow()

    private val _uiEvent = MutableSharedFlow<FormUiEvent>()
    val uiEvent: SharedFlow<FormUiEvent> = _uiEvent.asSharedFlow()

    init {
        val medicationId: Long? = savedStateHandle.get<Long>("medicationId")
        if (medicationId != null && medicationId > 0) {
            loadMedication(medicationId)
        }
    }

    private fun loadMedication(id: Long) {
        viewModelScope.launch {
            val medication = medicationRepository.getMedicationById(id)
            if (medication != null) {
                _formState.update {
                    it.copy(
                        medicationId = medication.id,
                        name = medication.name,
                        dosage = medication.dosage,
                        frequencyType = medication.frequencyType,
                        intervalHours = medication.intervalHours?.toString() ?: "",
                        specificDays = medication.specificDays.toSet(),
                        cycleActiveDays = medication.cycleActiveDays?.toString() ?: "",
                        cycleRestDays = medication.cycleRestDays?.toString() ?: "",
                        startDateTime = medication.startDateTime,
                        currentStock = medication.currentStock.toString(),
                        minStockThreshold = medication.minStockThreshold.toString(),
                        isEditMode = true
                    )
                }
            }
        }
    }

    fun onNameChange(name: String) {
        _formState.update { it.copy(name = name) }
    }

    fun onDosageChange(dosage: String) {
        _formState.update { it.copy(dosage = dosage) }
    }

    fun onFrequencyTypeChange(type: FrequencyType) {
        _formState.update { it.copy(frequencyType = type) }
    }

    fun onIntervalHoursChange(interval: String) {
        _formState.update { it.copy(intervalHours = interval) }
    }

    fun onDayToggle(day: DayOfWeek) {
        _formState.update {
            val newDays = it.specificDays.toMutableSet()
            if (newDays.contains(day)) newDays.remove(day) else newDays.add(day)
            it.copy(specificDays = newDays)
        }
    }

    fun onCycleActiveDaysChange(days: String) {
        _formState.update { it.copy(cycleActiveDays = days) }
    }

    fun onCycleRestDaysChange(days: String) {
        _formState.update { it.copy(cycleRestDays = days) }
    }

    fun onStartDateTimeChange(dateTime: LocalDateTime) {
        _formState.update { it.copy(startDateTime = dateTime) }
    }

    fun onCurrentStockChange(stock: String) {
        _formState.update { it.copy(currentStock = stock) }
    }

    fun onMinStockThresholdChange(threshold: String) {
        _formState.update { it.copy(minStockThreshold = threshold) }
    }

    fun saveMedication() {
        val current = _formState.value
        val isEdit = current.isEditMode

        val medication = Medication(
            id = current.medicationId,
            name = current.name.trim(),
            dosage = current.dosage.trim(),
            frequencyType = current.frequencyType,
            intervalHours = current.intervalHours.toIntOrNull(),
            specificDays = current.specificDays.toList().sorted(),
            cycleActiveDays = current.cycleActiveDays.toIntOrNull(),
            cycleRestDays = current.cycleRestDays.toIntOrNull(),
            startDateTime = current.startDateTime,
            currentStock = current.currentStock.toIntOrNull() ?: -1,
            minStockThreshold = current.minStockThreshold.toIntOrNull() ?: -1,
            isActive = true
        )

        val validation = validateMedicationUseCase(medication)
        _formState.update { it.copy(validationResult = validation) }

        if (!validation.isValid) {
            return
        }

        viewModelScope.launch {
            _formState.update { it.copy(isSaving = true) }
            val result = saveMedicationUseCase(medication)
            _formState.update { it.copy(isSaving = false) }

            if (result.isSuccess) {
                _uiEvent.emit(FormUiEvent.SaveSuccess(isEdit))
            } else {
                _uiEvent.emit(FormUiEvent.ShowError("Error al guardar el medicamento"))
            }
        }
    }
}
