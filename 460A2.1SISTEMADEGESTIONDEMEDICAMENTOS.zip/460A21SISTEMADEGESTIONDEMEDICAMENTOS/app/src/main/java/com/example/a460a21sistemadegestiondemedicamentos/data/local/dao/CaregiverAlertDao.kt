package com.example.a460a21sistemadegestiondemedicamentos.data.local.dao

// Módulo de cuidador removido según especificación
