package com.example.a460a21sistemadegestiondemedicamentos.ui.inventory

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.a460a21sistemadegestiondemedicamentos.R
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.FrequencyType
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import com.example.a460a21sistemadegestiondemedicamentos.ui.theme._460A21SISTEMADEGESTIONDEMEDICAMENTOSTheme
import java.time.LocalDateTime

@Composable
fun InventoryScreen(
    onNavigateBack: () -> Unit,
    viewModel: InventoryViewModel = hiltViewModel()
) {
    val medications by viewModel.medications.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    var selectedMedicationForRefill by remember { mutableStateOf<Medication?>(null) }

    LaunchedEffect(Unit) {
        viewModel.uiEvent.collect { event ->
            when (event) {
                is InventoryUiEvent.ShowSnackbar -> {
                    snackbarHostState.showSnackbar(event.message)
                }
            }
        }
    }

    InventoryContent(
        medications = medications,
        snackbarHostState = snackbarHostState,
        selectedMedicationForRefill = selectedMedicationForRefill,
        onDismissRefillDialog = { selectedMedicationForRefill = null },
        onConfirmRefill = { medication, quantity ->
            viewModel.refillStock(medication.id, quantity)
            selectedMedicationForRefill = null
        },
        onNavigateBack = onNavigateBack,
        onRefillClick = { selectedMedicationForRefill = it }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryContent(
    medications: List<Medication>,
    snackbarHostState: SnackbarHostState,
    selectedMedicationForRefill: Medication?,
    onDismissRefillDialog: () -> Unit,
    onConfirmRefill: (Medication, Int) -> Unit,
    onNavigateBack: () -> Unit,
    onRefillClick: (Medication) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.title_inventory)) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (medications.isEmpty()) {
                Text(
                    text = stringResource(R.string.no_inventory),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp)
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp)
                ) {
                    items(medications, key = { it.id }) { medication ->
                        InventoryCard(
                            medication = medication,
                            onRefillClick = { onRefillClick(medication) }
                        )
                    }
                }
            }
        }
    }

    selectedMedicationForRefill?.let { medication ->
        RefillStockDialog(
            medicationName = medication.name,
            onDismiss = onDismissRefillDialog,
            onConfirmRefill = { quantity ->
                onConfirmRefill(medication, quantity)
            }
        )
    }
}

@Composable
fun InventoryCard(
    medication: Medication,
    onRefillClick: () -> Unit
) {
    val isLowStock = medication.currentStock <= medication.minStockThreshold
    val maxStockForProgress = maxOf(medication.minStockThreshold * 3, medication.currentStock, 1)
    val progress = (medication.currentStock.toFloat() / maxStockForProgress.toFloat()).coerceIn(0f, 1f)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isLowStock) {
                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = medication.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Dosis: ${medication.dosage}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Button(
                    onClick = onRefillClick,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.AddCircleOutline, contentDescription = null)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(stringResource(R.string.refill_stock))
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp)),
                color = if (isLowStock) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isLowStock) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(end = 4.dp)
                        )
                        Text(
                            text = stringResource(R.string.stock_low_warning, medication.currentStock),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Text(
                        text = stringResource(R.string.stock_label, medication.currentStock),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Text(
                    text = "Umbral min: ${medication.minStockThreshold} uds",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun RefillStockDialog(
    medicationName: String,
    onDismiss: () -> Unit,
    onConfirmRefill: (Int) -> Unit
) {
    var quantityText by remember { mutableStateOf("10") }
    var isError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.refill_stock_title, medicationName)) },
        text = {
            Column {
                OutlinedTextField(
                    value = quantityText,
                    onValueChange = {
                        quantityText = it
                        isError = false
                    },
                    label = { Text(stringResource(R.string.refill_quantity_label)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    isError = isError,
                    supportingText = if (isError) {
                        { Text(stringResource(R.string.error_invalid_quantity)) }
                    } else null,
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val qty = quantityText.toIntOrNull()
                    if (qty != null && qty > 0) {
                        onConfirmRefill(qty)
                    } else {
                        isError = true
                    }
                }
            ) {
                Text(stringResource(R.string.accept))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel))
            }
        }
    )
}

@Preview(showBackground = true)
@Composable
fun InventoryScreenPreview() {
    val now = LocalDateTime.now()
    _460A21SISTEMADEGESTIONDEMEDICAMENTOSTheme {
        InventoryContent(
            medications = listOf(
                Medication(
                    id = 1,
                    name = "Paracetamol",
                    dosage = "500 mg",
                    frequencyType = FrequencyType.EVERY_X_HOURS,
                    intervalHours = 8,
                    startDateTime = now,
                    currentStock = 3,
                    minStockThreshold = 5
                ),
                Medication(
                    id = 2,
                    name = "Ibuprofeno",
                    dosage = "400 mg",
                    frequencyType = FrequencyType.EVERY_X_HOURS,
                    intervalHours = 12,
                    startDateTime = now,
                    currentStock = 25,
                    minStockThreshold = 5
                )
            ),
            snackbarHostState = remember { SnackbarHostState() },
            selectedMedicationForRefill = null,
            onDismissRefillDialog = {},
            onConfirmRefill = { _, _ -> },
            onNavigateBack = {},
            onRefillClick = {}
        )
    }
}
