package com.example.a460a21sistemadegestiondemedicamentos.domain.usecase

import com.example.a460a21sistemadegestiondemedicamentos.domain.alarm.AlarmScheduler
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.DoseLogRepository
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.MedicationRepository
import javax.inject.Inject

/**
 * Caso de uso para eliminar un medicamento y sus recursos asociados (alarmas e historial de tomas).
 */
class DeleteMedicationUseCase @Inject constructor(
    private val medicationRepository: MedicationRepository,
    private val doseLogRepository: DoseLogRepository,
    private val alarmScheduler: AlarmScheduler
) {

    suspend operator fun invoke(medicationId: Long) {
        alarmScheduler.cancelAlarm(medicationId)
        doseLogRepository.deleteLogsForMedication(medicationId)
        medicationRepository.deleteMedication(medicationId)
    }
}
