package com.example.a460a21sistemadegestiondemedicamentos.data.repository

import com.example.a460a21sistemadegestiondemedicamentos.data.local.dao.DoseLogDao
import com.example.a460a21sistemadegestiondemedicamentos.data.mapper.toDomain
import com.example.a460a21sistemadegestiondemedicamentos.data.mapper.toEntity
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.DoseLog
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.DoseLogRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DoseLogRepositoryImpl @Inject constructor(
    private val doseLogDao: DoseLogDao
) : DoseLogRepository {

    private val formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME

    override fun getAllDoseLogs(): Flow<List<DoseLog>> {
        return doseLogDao.getAllDoseLogs().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override fun getDoseLogsByMedication(medicationId: Long): Flow<List<DoseLog>> {
        return doseLogDao.getDoseLogsByMedication(medicationId).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override fun getDoseLogsByDateRange(startDate: LocalDateTime, endDate: LocalDateTime): Flow<List<DoseLog>> {
        return doseLogDao.getDoseLogsByDateRange(
            startDate.format(formatter),
            endDate.format(formatter)
        ).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override fun getDoseLogsByMedicationAndDateRange(
        medicationId: Long,
        startDate: LocalDateTime,
        endDate: LocalDateTime
    ): Flow<List<DoseLog>> {
        return doseLogDao.getDoseLogsByMedicationAndDateRange(
            medicationId,
            startDate.format(formatter),
            endDate.format(formatter)
        ).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override suspend fun getDoseLogById(id: Long): DoseLog? {
        return doseLogDao.getDoseLogById(id)?.toDomain()
    }

    override suspend fun getDoseLogByScheduledTime(medicationId: Long, scheduledDateTime: LocalDateTime): DoseLog? {
        return doseLogDao.getDoseLogByScheduledTime(medicationId, scheduledDateTime.format(formatter))?.toDomain()
    }

    override suspend fun recordDoseLog(doseLog: DoseLog): Long {
        return doseLogDao.insertDoseLog(doseLog.toEntity())
    }

    override suspend fun updateDoseLog(doseLog: DoseLog) {
        doseLogDao.updateDoseLog(doseLog.toEntity())
    }

    override suspend fun deleteLogsForMedication(medicationId: Long) {
        doseLogDao.deleteLogsForMedication(medicationId)
    }
}
