package com.example.a460a21sistemadegestiondemedicamentos.data.local.entity

// Módulo de cuidador removido según especificación
