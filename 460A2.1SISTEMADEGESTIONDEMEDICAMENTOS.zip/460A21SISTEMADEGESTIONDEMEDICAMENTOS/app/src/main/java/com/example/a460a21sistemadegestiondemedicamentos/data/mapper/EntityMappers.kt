package com.example.a460a21sistemadegestiondemedicamentos.data.mapper

import com.example.a460a21sistemadegestiondemedicamentos.data.local.entity.DoseLogEntity
import com.example.a460a21sistemadegestiondemedicamentos.data.local.entity.MedicationEntity
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.DoseLog
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.DoseStatus
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.FrequencyType
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import java.time.DayOfWeek
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

private val dateTimeFormatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME

// Medication Mappers
fun MedicationEntity.toDomain(): Medication {
    val daysList = if (specificDays.isBlank()) emptyList() else specificDays.split(",").mapNotNull {
        try { DayOfWeek.valueOf(it.trim()) } catch (e: IllegalArgumentException) { null }
    }
    return Medication(
        id = id,
        name = name,
        dosage = dosage,
        frequencyType = FrequencyType.valueOf(frequencyType),
        intervalHours = intervalHours,
        specificDays = daysList,
        cycleActiveDays = cycleActiveDays,
        cycleRestDays = cycleRestDays,
        startDateTime = LocalDateTime.parse(startDateTime, dateTimeFormatter),
        currentStock = currentStock,
        minStockThreshold = minStockThreshold,
        isActive = isActive
    )
}

fun Medication.toEntity(): MedicationEntity {
    return MedicationEntity(
        id = id,
        name = name,
        dosage = dosage,
        frequencyType = frequencyType.name,
        intervalHours = intervalHours,
        specificDays = specificDays.joinToString(",") { it.name },
        cycleActiveDays = cycleActiveDays,
        cycleRestDays = cycleRestDays,
        startDateTime = startDateTime.format(dateTimeFormatter),
        currentStock = currentStock,
        minStockThreshold = minStockThreshold,
        isActive = isActive
    )
}

// DoseLog Mappers
fun DoseLogEntity.toDomain(): DoseLog {
    return DoseLog(
        id = id,
        medicationId = medicationId,
        scheduledDateTime = LocalDateTime.parse(scheduledDateTime, dateTimeFormatter),
        actionDateTime = actionDateTime?.let { LocalDateTime.parse(it, dateTimeFormatter) },
        status = DoseStatus.valueOf(status)
    )
}

fun DoseLog.toEntity(): DoseLogEntity {
    return DoseLogEntity(
        id = id,
        medicationId = medicationId,
        scheduledDateTime = scheduledDateTime.format(dateTimeFormatter),
        actionDateTime = actionDateTime?.format(dateTimeFormatter),
        status = status.name
    )
}
