package com.example.a460a21sistemadegestiondemedicamentos.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.a460a21sistemadegestiondemedicamentos.data.local.dao.DoseLogDao
import com.example.a460a21sistemadegestiondemedicamentos.data.local.dao.MedicationDao
import com.example.a460a21sistemadegestiondemedicamentos.data.local.entity.DoseLogEntity
import com.example.a460a21sistemadegestiondemedicamentos.data.local.entity.MedicationEntity

@Database(
    entities = [
        MedicationEntity::class,
        DoseLogEntity::class
    ],
    version = 2,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun medicationDao(): MedicationDao
    abstract fun doseLogDao(): DoseLogDao

    companion object {
        const val DATABASE_NAME = "medication_db"
    }
}
