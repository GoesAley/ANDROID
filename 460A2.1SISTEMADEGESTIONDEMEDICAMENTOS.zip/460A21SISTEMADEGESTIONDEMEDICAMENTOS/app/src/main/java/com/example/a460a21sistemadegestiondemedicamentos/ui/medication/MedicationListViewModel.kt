package com.example.a460a21sistemadegestiondemedicamentos.ui.medication

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.a460a21sistemadegestiondemedicamentos.domain.alarm.AlarmScheduler
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.DoseLog
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.DoseStatus
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.DoseLogRepository
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.MedicationRepository
import com.example.a460a21sistemadegestiondemedicamentos.domain.usecase.DeleteMedicationUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import javax.inject.Inject

sealed class ListUiEvent {
    data class ShowSnackbar(val message: String) : ListUiEvent()
}

@HiltViewModel
class MedicationListViewModel @Inject constructor(
    private val medicationRepository: MedicationRepository,
    private val doseLogRepository: DoseLogRepository,
    private val deleteMedicationUseCase: DeleteMedicationUseCase,
    private val alarmScheduler: AlarmScheduler
) : ViewModel() {

    val medications: StateFlow<List<Medication>> = medicationRepository.getAllActiveMedications()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _uiEvent = MutableSharedFlow<ListUiEvent>()
    val uiEvent: SharedFlow<ListUiEvent> = _uiEvent.asSharedFlow()

    fun showSnackbarMessage(message: String) {
        viewModelScope.launch {
            _uiEvent.emit(ListUiEvent.ShowSnackbar(message))
        }
    }

    fun recordDoseAction(medication: Medication, status: DoseStatus) {
        viewModelScope.launch {
            try {
                if (status == DoseStatus.TAKEN) {
                    doseLogRepository.recordDoseLog(
                        DoseLog(
                            medicationId = medication.id,
                            scheduledDateTime = LocalDateTime.now(),
                            actionDateTime = LocalDateTime.now(),
                            status = DoseStatus.TAKEN
                        )
                    )
                    medicationRepository.decrementStock(medication.id)
                    val updated = medicationRepository.getMedicationById(medication.id)
                    if (updated != null && updated.isActive) {
                        alarmScheduler.scheduleNextAlarm(updated)
                    }
                    _uiEvent.emit(ListUiEvent.ShowSnackbar("Toma de \"${medication.name}\" registrada correctamente"))
                } else if (status == DoseStatus.POSTPONED) {
                    doseLogRepository.recordDoseLog(
                        DoseLog(
                            medicationId = medication.id,
                            scheduledDateTime = LocalDateTime.now(),
                            actionDateTime = LocalDateTime.now(),
                            status = DoseStatus.POSTPONED
                        )
                    )
                    val postponed = medication.copy(startDateTime = LocalDateTime.now().plusMinutes(15))
                    alarmScheduler.scheduleNextAlarm(postponed)
                    _uiEvent.emit(ListUiEvent.ShowSnackbar("Toma de \"${medication.name}\" pospuesta 15 minutos"))
                }
            } catch (e: Exception) {
                _uiEvent.emit(ListUiEvent.ShowSnackbar("Error al procesar la toma"))
            }
        }
    }

    fun deleteMedication(id: Long, name: String) {
        viewModelScope.launch {
            try {
                deleteMedicationUseCase(id)
                _uiEvent.emit(ListUiEvent.ShowSnackbar("Medicamento \"$name\" eliminado"))
            } catch (e: Exception) {
                _uiEvent.emit(ListUiEvent.ShowSnackbar("Error al eliminar el medicamento"))
            }
        }
    }

    fun addStock(id: Long, quantity: Int) {
        viewModelScope.launch {
            try {
                medicationRepository.addStock(id, quantity)
                _uiEvent.emit(ListUiEvent.ShowSnackbar("Stock actualizado correctamente"))
            } catch (e: Exception) {
                _uiEvent.emit(ListUiEvent.ShowSnackbar("Error al actualizar el stock"))
            }
        }
    }
}
