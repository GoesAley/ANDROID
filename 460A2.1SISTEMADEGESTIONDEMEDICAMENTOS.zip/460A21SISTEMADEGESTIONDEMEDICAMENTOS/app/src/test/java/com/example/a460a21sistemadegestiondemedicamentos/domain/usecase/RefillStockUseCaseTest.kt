package com.example.a460a21sistemadegestiondemedicamentos.domain.usecase

import com.example.a460a21sistemadegestiondemedicamentos.domain.model.FrequencyType
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.time.LocalDateTime

class RefillStockUseCaseTest {

    private lateinit var fakeRepository: FakeMedicationRepository
    private lateinit var refillStockUseCase: RefillStockUseCase

    @Before
    fun setUp() {
        fakeRepository = FakeMedicationRepository()
        refillStockUseCase = RefillStockUseCase(fakeRepository)
    }

    @Test
    fun refillValidQuantity_increasesCurrentStock() = runBlocking {
        val medication = Medication(
            id = 1,
            name = "Paracetamol",
            dosage = "500 mg",
            frequencyType = FrequencyType.EVERY_X_HOURS,
            startDateTime = LocalDateTime.now(),
            currentStock = 5,
            minStockThreshold = 3
        )
        fakeRepository.insertedMedications.add(medication)

        val result = refillStockUseCase(medicationId = 1, quantity = 20)

        assertTrue(result.isSuccess)
        assertEquals(25, fakeRepository.getMedicationById(1)?.currentStock)
    }

    @Test
    fun refillZeroOrNegativeQuantity_returnsFailure() = runBlocking {
        val result = refillStockUseCase(medicationId = 1, quantity = 0)

        assertTrue(result.isFailure)
    }
}
