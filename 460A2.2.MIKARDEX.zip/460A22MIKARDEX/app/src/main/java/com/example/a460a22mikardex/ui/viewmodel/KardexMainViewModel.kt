package com.example.a460a22mikardex.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.a460a22mikardex.data.local.MateriaKardex
import com.example.a460a22mikardex.data.repository.KardexRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale

data class PerfilUiState(
    val nombre: String = "",
    val numeroControl: String = "",
    val nombreError: String? = null,
    val numeroControlError: String? = null,
    val mensajeExito: String? = null,
    val isEditing: Boolean = false,
    val estaGuardado: Boolean = false
)

data class MateriaFormUiState(
    val nombre: String = "",
    val semestre: String = "",
    val oportunidad: String = "Normal", // "Normal", "Repetición", "Especial", "Verano"
    val calificacion: String = "",

    val nombreError: String? = null,
    val semestreError: String? = null,
    val calificacionError: String? = null,
    val mensajeExito: String? = null
)

/**
 * ViewModel unificado para la pantalla única del Kardex Académico.
 */
class KardexMainViewModel(private val repository: KardexRepository) : ViewModel() {

    // --- HU-01: PERFIL STATE ---
    private val _perfilState = MutableStateFlow(PerfilUiState())
    val perfilState: StateFlow<PerfilUiState> = _perfilState.asStateFlow()

    // --- HU-02: FORM STATE ---
    private val _materiaFormState = MutableStateFlow(MateriaFormUiState())
    val materiaFormState: StateFlow<MateriaFormUiState> = _materiaFormState.asStateFlow()

    // --- HU-03: FILTRO Y PROMEDIOS ---
    private val _semestreFiltro = MutableStateFlow("")
    val semestreFiltro: StateFlow<String> = _semestreFiltro.asStateFlow()

    // --- HU-04: HISTORIAL DE MATERIAS DESDE ROOM ---
    val todasLasMaterias: StateFlow<List<MateriaKardex>> = repository.todasLasMaterias
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val promedioGeneral: StateFlow<String> = todasLasMaterias
        .combine(MutableStateFlow(Unit)) { materias, _ ->
            calcularPromedio(materias)
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = "Sin datos"
        )

    val promedioPorSemestre: StateFlow<String> = combine(todasLasMaterias, _semestreFiltro) { materias, filtro ->
        val semestreInt = filtro.toIntOrNull()
        if (semestreInt == null || semestreInt !in 1..12) {
            "Sin datos"
        } else {
            val materiasFiltradas = materias.filter { it.semestre == semestreInt }
            calcularPromedio(materiasFiltradas)
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = "Sin datos"
    )

    // Estado eliminación
    private val _materiaAEliminar = MutableStateFlow<MateriaKardex?>(null)
    val materiaAEliminar: StateFlow<MateriaKardex?> = _materiaAEliminar.asStateFlow()

    init {
        cargarPerfil()
    }

    // --- MÉTODOS HU-01 ---
    private fun cargarPerfil() {
        val nombre = repository.obtenerNombreAlumno()
        val numControl = repository.obtenerNumeroControlAlumno()
        val hasData = nombre.isNotBlank() && numControl.isNotBlank()
        _perfilState.update {
            it.copy(
                nombre = nombre,
                numeroControl = numControl,
                isEditing = !hasData,
                estaGuardado = hasData
            )
        }
    }

    fun activarEdicionPerfil() {
        _perfilState.update {
            it.copy(isEditing = true, mensajeExito = null)
        }
    }

    fun onNombrePerfilChanged(nuevoNombre: String) {
        _perfilState.update {
            it.copy(
                nombre = nuevoNombre,
                nombreError = if (nuevoNombre.isNotBlank()) null else it.nombreError,
                mensajeExito = null
            )
        }
    }

    fun onNumeroControlPerfilChanged(nuevoNumControl: String) {
        _perfilState.update {
            it.copy(
                numeroControl = nuevoNumControl,
                numeroControlError = if (nuevoNumControl.isNotBlank()) null else it.numeroControlError,
                mensajeExito = null
            )
        }
    }

    fun guardarDatosPersonales(): Boolean {
        val currentNombre = _perfilState.value.nombre.trim()
        val currentNumControl = _perfilState.value.numeroControl.trim()

        var hasError = false
        var errNombre: String? = null
        var errNumControl: String? = null

        if (currentNombre.isBlank()) {
            errNombre = "El nombre no puede estar vacío"
            hasError = true
        }

        if (currentNumControl.isBlank()) {
            errNumControl = "El número de control no puede estar vacío"
            hasError = true
        }

        if (hasError) {
            _perfilState.update {
                it.copy(
                    nombreError = errNombre,
                    numeroControlError = errNumControl,
                    mensajeExito = null
                )
            }
            return false
        }

        repository.guardarDatosPersonales(currentNombre, currentNumControl)
        _perfilState.update {
            it.copy(
                nombre = currentNombre,
                numeroControl = currentNumControl,
                nombreError = null,
                numeroControlError = null,
                mensajeExito = "Datos guardados correctamente",
                isEditing = false,
                estaGuardado = true
            )
        }
        return true
    }

    fun limpiarMensajeExitoPerfil() {
        _perfilState.update { it.copy(mensajeExito = null) }
    }

    // --- MÉTODOS HU-02 Y HU-03 ---
    fun onNombreMateriaChanged(value: String) {
        _materiaFormState.update { it.copy(nombre = value, nombreError = null, mensajeExito = null) }
    }

    fun onSemestreMateriaChanged(value: String) {
        _materiaFormState.update { it.copy(semestre = value, semestreError = null, mensajeExito = null) }
    }

    fun onOportunidadMateriaChanged(value: String) {
        _materiaFormState.update { it.copy(oportunidad = value, calificacionError = null, mensajeExito = null) }
    }

    fun onCalificacionMateriaChanged(value: String) {
        _materiaFormState.update { it.copy(calificacion = value, calificacionError = null, mensajeExito = null) }
    }

    fun onSemestreFiltroChanged(value: String) {
        _semestreFiltro.value = value
    }

    fun guardarMateria() {
        val state = _materiaFormState.value
        val nombreTrimmed = state.nombre.trim()
        val semestreInt = state.semestre.trim().toIntOrNull()
        val califDouble = state.calificacion.trim().toDoubleOrNull()

        var isValid = true
        var errNombre: String? = null
        var errSemestre: String? = null
        var errCalificacion: String? = null

        if (nombreTrimmed.isBlank()) {
            errNombre = "El nombre de la materia es obligatorio"
            isValid = false
        }

        if (semestreInt == null || semestreInt !in 1..12) {
            errSemestre = "Ingrese un semestre válido entre 1 y 12"
            isValid = false
        }

        if (state.calificacion.trim().isEmpty()) {
            errCalificacion = "Ingrese la calificación para el curso seleccionado"
            isValid = false
        } else if (califDouble == null || califDouble < 0.0 || califDouble > 100.0) {
            errCalificacion = "Debe ser un número entre 0 y 100"
            isValid = false
        }

        if (!isValid) {
            _materiaFormState.update {
                it.copy(
                    nombreError = errNombre,
                    semestreError = errSemestre,
                    calificacionError = errCalificacion,
                    mensajeExito = null
                )
            }
            return
        }

        val materia = MateriaKardex(
            nombre = nombreTrimmed,
            semestre = semestreInt!!,
            normal = if (state.oportunidad == "Normal") califDouble else null,
            repeticion = if (state.oportunidad == "Repetición") califDouble else null,
            especial = if (state.oportunidad == "Especial") califDouble else null,
            verano = if (state.oportunidad == "Verano") califDouble else null
        )

        viewModelScope.launch {
            repository.insertarMateria(materia)
            _materiaFormState.value = MateriaFormUiState(
                mensajeExito = "Datos guardados correctamente"
            )
        }
    }

    fun limpiarMensajeExitoMateria() {
        _materiaFormState.update { it.copy(mensajeExito = null) }
    }

    // --- MÉTODOS HU-04 (ELIMINAR) ---
    fun solicitarEliminacion(materia: MateriaKardex) {
        _materiaAEliminar.value = materia
    }

    fun cancelarEliminacion() {
        _materiaAEliminar.value = null
    }

    fun confirmarEliminacion() {
        val materia = _materiaAEliminar.value ?: return
        viewModelScope.launch {
            repository.eliminarMateria(materia)
            _materiaAEliminar.value = null
        }
    }

    private fun calcularPromedio(materias: List<MateriaKardex>): String {
        if (materias.isEmpty()) return "Sin datos"

        val calificacionesValidas = materias.mapNotNull { it.calificacionFinal }
        if (calificacionesValidas.isEmpty()) return "Sin datos"

        val promedio = calificacionesValidas.average()
        return String.format(Locale.US, "%.2f", promedio)
    }
}

class KardexMainViewModelFactory(private val repository: KardexRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(KardexMainViewModel::class.java)) {
            return KardexMainViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
