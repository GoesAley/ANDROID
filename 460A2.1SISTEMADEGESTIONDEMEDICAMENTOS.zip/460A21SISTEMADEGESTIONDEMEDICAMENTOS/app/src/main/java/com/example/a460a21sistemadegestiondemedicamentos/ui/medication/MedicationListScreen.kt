package com.example.a460a21sistemadegestiondemedicamentos.ui.medication

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ListAlt
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.a460a21sistemadegestiondemedicamentos.R
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.DoseStatus
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.FrequencyType
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import com.example.a460a21sistemadegestiondemedicamentos.ui.theme._460A21SISTEMADEGESTIONDEMEDICAMENTOSTheme
import java.time.DayOfWeek
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Composable
fun MedicationListScreen(
    resultMessage: String? = null,
    onResultMessageConsumed: () -> Unit = {},
    onNavigateToAdd: () -> Unit,
    onNavigateToEdit: (Long) -> Unit,
    onNavigateToDetail: (Long) -> Unit,
    onNavigateToWeeklySchedule: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToInventory: () -> Unit,
    viewModel: MedicationListViewModel = hiltViewModel()
) {
    val medications by viewModel.medications.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    var medicationToDelete by remember { mutableStateOf<Medication?>(null) }
    var medicationForDoseDialog by remember { mutableStateOf<Medication?>(null) }

    LaunchedEffect(resultMessage) {
        if (!resultMessage.isNullOrBlank()) {
            snackbarHostState.showSnackbar(resultMessage)
            onResultMessageConsumed()
        }
    }

    LaunchedEffect(Unit) {
        viewModel.uiEvent.collect { event ->
            when (event) {
                is ListUiEvent.ShowSnackbar -> {
                    snackbarHostState.showSnackbar(event.message)
                }
            }
        }
    }

    MedicationListContent(
        medications = medications,
        snackbarHostState = snackbarHostState,
        medicationToDelete = medicationToDelete,
        medicationForDoseDialog = medicationForDoseDialog,
        onDismissDeleteDialog = { medicationToDelete = null },
        onDismissDoseDialog = { medicationForDoseDialog = null },
        onConfirmDelete = { medication ->
            viewModel.deleteMedication(medication.id, medication.name)
            medicationToDelete = null
        },
        onTakeDose = { medication ->
            viewModel.recordDoseAction(medication, DoseStatus.TAKEN)
            medicationForDoseDialog = null
        },
        onPostponeDose = { medication ->
            viewModel.recordDoseAction(medication, DoseStatus.POSTPONED)
            medicationForDoseDialog = null
        },
        onNavigateToAdd = onNavigateToAdd,
        onNavigateToEdit = onNavigateToEdit,
        onNavigateToDetail = onNavigateToDetail,
        onNavigateToWeeklySchedule = onNavigateToWeeklySchedule,
        onNavigateToHistory = onNavigateToHistory,
        onNavigateToInventory = onNavigateToInventory,
        onDeleteClick = { medicationToDelete = it },
        onOpenDoseDialogClick = { medicationForDoseDialog = it },
        onQuickStockAdd = { id -> viewModel.addStock(id, 10) }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedicationListContent(
    medications: List<Medication>,
    snackbarHostState: SnackbarHostState,
    medicationToDelete: Medication?,
    medicationForDoseDialog: Medication?,
    onDismissDeleteDialog: () -> Unit,
    onDismissDoseDialog: () -> Unit,
    onConfirmDelete: (Medication) -> Unit,
    onTakeDose: (Medication) -> Unit,
    onPostponeDose: (Medication) -> Unit,
    onNavigateToAdd: () -> Unit,
    onNavigateToEdit: (Long) -> Unit,
    onNavigateToDetail: (Long) -> Unit,
    onNavigateToWeeklySchedule: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToInventory: () -> Unit,
    onDeleteClick: (Medication) -> Unit,
    onOpenDoseDialogClick: (Medication) -> Unit,
    onQuickStockAdd: (Long) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.title_medications)) },
                actions = {
                    IconButton(onClick = onNavigateToWeeklySchedule) {
                        Icon(
                            imageVector = Icons.Default.DateRange,
                            contentDescription = "Calendario Semanal"
                        )
                    }
                    IconButton(onClick = onNavigateToHistory) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ListAlt,
                            contentDescription = stringResource(R.string.title_dose_history)
                        )
                    }
                    IconButton(onClick = onNavigateToInventory) {
                        Icon(
                            imageVector = Icons.Default.ShoppingCart,
                            contentDescription = stringResource(R.string.title_inventory)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onNavigateToAdd,
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = stringResource(R.string.add_medication)
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (medications.isEmpty()) {
                Text(
                    text = stringResource(R.string.no_medications),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp)
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp)
                ) {
                    items(medications, key = { it.id }) { medication ->
                        MedicationItemCard(
                            medication = medication,
                            onClick = { onNavigateToDetail(medication.id) },
                            onOpenDoseDialog = { onOpenDoseDialogClick(medication) },
                            onEdit = { onNavigateToEdit(medication.id) },
                            onDelete = { onDeleteClick(medication) },
                            onQuickStockAdd = { onQuickStockAdd(medication.id) }
                        )
                    }
                }
            }
        }
    }

    // Diálogo emergente en pantalla para Tomar o Posponer la toma
    medicationForDoseDialog?.let { medication ->
        DueDoseAlertDialog(
            medication = medication,
            onDismiss = onDismissDoseDialog,
            onTakeDose = { onTakeDose(medication) },
            onPostponeDose = { onPostponeDose(medication) }
        )
    }

    // Diálogo de confirmación para eliminar
    medicationToDelete?.let { medication ->
        AlertDialog(
            onDismissRequest = onDismissDeleteDialog,
            title = { Text(stringResource(R.string.delete_confirm_title)) },
            text = { Text(stringResource(R.string.delete_confirm_message, medication.name)) },
            confirmButton = {
                TextButton(
                    onClick = { onConfirmDelete(medication) }
                ) {
                    Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissDeleteDialog) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
}

@Composable
fun DueDoseAlertDialog(
    medication: Medication,
    onDismiss: () -> Unit,
    onTakeDose: () -> Unit,
    onPostponeDose: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Registro de Toma",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        },
        text = {
            Column {
                Text(
                    text = medication.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Dosis: ${medication.dosage}",
                    style = MaterialTheme.typography.bodyLarge
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "¿Deseas registrar la toma ahora o posponerla 15 minutos?",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onTakeDose,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("Tomar toma")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onPostponeDose
            ) {
                Text("Posponer toma")
            }
        }
    )
}

@Composable
fun MedicationItemCard(
    medication: Medication,
    onClick: () -> Unit,
    onOpenDoseDialog: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onQuickStockAdd: () -> Unit
) {
    val isLowStock = medication.currentStock <= medication.minStockThreshold

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isLowStock) {
                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.25f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = medication.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Dosis: ${medication.dosage}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                Row {
                    IconButton(onClick = onQuickStockAdd) {
                        Icon(
                            imageVector = Icons.Default.AddCircleOutline,
                            contentDescription = "Recarga rápida de stock"
                        )
                    }
                    IconButton(onClick = onEdit) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = stringResource(R.string.edit)
                        )
                    }
                    IconButton(onClick = onDelete) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = stringResource(R.string.delete),
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = formatFrequencyDescription(medication),
                style = MaterialTheme.typography.bodySmall
            )

            val formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")
            Text(
                text = stringResource(R.string.start_date_label, medication.startDateTime.format(formatter)),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isLowStock) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(end = 4.dp)
                        )
                        Text(
                            text = stringResource(R.string.stock_low_warning, medication.currentStock),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Text(
                        text = stringResource(R.string.stock_label, medication.currentStock),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                // Botón destacado en cada tarjeta para abrir el mensaje emergente de Toma o Posponer toma
                Button(
                    onClick = onOpenDoseDialog,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        modifier = Modifier.padding(end = 4.dp)
                    )
                    Text("Registrar toma")
                }
            }
        }
    }
}

fun getSpanishDayName(day: DayOfWeek): String {
    return when (day) {
        DayOfWeek.MONDAY -> "Lun"
        DayOfWeek.TUESDAY -> "Mar"
        DayOfWeek.WEDNESDAY -> "Mié"
        DayOfWeek.THURSDAY -> "Jue"
        DayOfWeek.FRIDAY -> "Vie"
        DayOfWeek.SATURDAY -> "Sáb"
        DayOfWeek.SUNDAY -> "Dom"
    }
}

@Composable
fun formatFrequencyDescription(medication: Medication): String {
    return when (medication.frequencyType) {
        FrequencyType.EVERY_X_HOURS -> "Cada ${medication.intervalHours ?: 0} horas"
        FrequencyType.SPECIFIC_DAYS -> "Días: " + medication.specificDays.joinToString(", ") { getSpanishDayName(it) }
        FrequencyType.ALTERNATE_DAYS -> "Días alternos (1 día sí, 1 día no)"
        FrequencyType.CYCLE -> "Ciclo: ${medication.cycleActiveDays ?: 0} días sí / ${medication.cycleRestDays ?: 0} días descanso"
    }
}

@Preview(showBackground = true)
@Composable
fun MedicationListScreenPreview() {
    _460A21SISTEMADEGESTIONDEMEDICAMENTOSTheme {
        MedicationListContent(
            medications = listOf(
                Medication(
                    id = 1,
                    name = "Paracetamol",
                    dosage = "500 mg",
                    frequencyType = FrequencyType.EVERY_X_HOURS,
                    intervalHours = 8,
                    startDateTime = LocalDateTime.now(),
                    currentStock = 3,
                    minStockThreshold = 5
                )
            ),
            snackbarHostState = remember { SnackbarHostState() },
            medicationToDelete = null,
            medicationForDoseDialog = null,
            onDismissDeleteDialog = {},
            onDismissDoseDialog = {},
            onConfirmDelete = {},
            onTakeDose = {},
            onPostponeDose = {},
            onNavigateToAdd = {},
            onNavigateToEdit = {},
            onNavigateToDetail = {},
            onNavigateToWeeklySchedule = {},
            onNavigateToHistory = {},
            onNavigateToInventory = {},
            onDeleteClick = {},
            onOpenDoseDialogClick = {},
            onQuickStockAdd = {}
        )
    }
}
