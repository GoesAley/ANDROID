package com.example.a460a21sistemadegestiondemedicamentos.domain.model

/**
 * Tipos de frecuencia soportados para el consumo de medicamentos.
 */
enum class FrequencyType {
    EVERY_X_HOURS,     // Se toma cada X horas (ej. cada 8 horas)
    SPECIFIC_DAYS,     // Días específicos de la semana (ej. LUN, MIE, VIE)
    ALTERNATE_DAYS,    // Días alternos (un día sí, un día no)
    CYCLE              // Patrón de ciclo (ej. 5 días de consumo / 2 días de descanso)
}
