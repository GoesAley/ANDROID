package com.example.a460a21sistemadegestiondemedicamentos.data.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.a460a21sistemadegestiondemedicamentos.domain.alarm.AlarmScheduler
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.MedicationRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class BootReceiver : BroadcastReceiver() {

    @Inject
    lateinit var medicationRepository: MedicationRepository

    @Inject
    lateinit var alarmScheduler: AlarmScheduler

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val activeMedications = medicationRepository.getAllActiveMedications().first()
                    activeMedications.forEach { medication ->
                        alarmScheduler.scheduleNextAlarm(medication)
                    }
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
