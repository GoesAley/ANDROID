package com.example.a460a21sistemadegestiondemedicamentos.domain.usecase

import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.MedicationRepository
import javax.inject.Inject

/**
 * Caso de uso para realizar la recarga rápida o manual de stock de un medicamento.
 */
class RefillStockUseCase @Inject constructor(
    private val medicationRepository: MedicationRepository
) {

    suspend operator fun invoke(medicationId: Long, quantity: Int): Result<Unit> {
        if (quantity <= 0) {
            return Result.failure(IllegalArgumentException("La cantidad debe ser mayor a 0"))
        }

        return try {
            medicationRepository.addStock(medicationId, quantity)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
