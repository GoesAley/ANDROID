package com.example.a460a21sistemadegestiondemedicamentos.data.local

import androidx.room.TypeConverter
import java.time.DayOfWeek
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * Convertidores de tipo para Room que permiten almacenar objetos Java Time y colecciones en SQLite.
 */
class Converters {

    private val formatter: DateTimeFormatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME

    @TypeConverter
    fun fromLocalDateTime(value: LocalDateTime?): String? {
        return value?.format(formatter)
    }

    @TypeConverter
    fun toLocalDateTime(value: String?): LocalDateTime? {
        return value?.let { LocalDateTime.parse(it, formatter) }
    }

    @TypeConverter
    fun fromDayOfWeekList(list: List<DayOfWeek>?): String {
        return list?.joinToString(",") { it.name } ?: ""
    }

    @TypeConverter
    fun toDayOfWeekList(value: String?): List<DayOfWeek> {
        if (value.isNullOrBlank()) return emptyList()
        return value.split(",").mapNotNull { name ->
            try {
                DayOfWeek.valueOf(name.trim())
            } catch (e: IllegalArgumentException) {
                null
            }
        }
    }
}
