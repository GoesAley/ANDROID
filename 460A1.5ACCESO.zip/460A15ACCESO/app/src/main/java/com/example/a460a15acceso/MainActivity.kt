package com.example.a460a15acceso

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.a460a15acceso.R
import java.io.File
import java.io.FileOutputStream

val TecNMAzulMarino = Color(0xFF1B396A)
val TecNMAzulClaro = Color(0xFF0071CE)

const val NUMERO_CONTROL_VALIDO = "22270460"
const val PASSWORD_VALIDA = "012345678"
const val PROFILE_IMAGE_NAME = "profile_picture.png"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val customColorScheme = lightColorScheme(
                primary = TecNMAzulMarino,
                secondary = TecNMAzulClaro,
                background = Color(0xFFF5F7FA)
            )

            MaterialTheme(colorScheme = customColorScheme) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation()
                }
            }
        }
    }
}

@Composable
fun AppNavigation() {
    var isLoggedIn by remember { mutableStateOf(false) }
    var usuarioLogueado by remember { mutableStateOf("") }

    if (!isLoggedIn) {
        LoginScreen(
            onLoginSuccess = { numControl ->
                usuarioLogueado = numControl
                isLoggedIn = true
            }
        )
    } else {
        ProfileScreen(
            numeroControl = usuarioLogueado,
            onLogout = { isLoggedIn = false }
        )
    }
}

@Composable
fun LoginScreen(onLoginSuccess: (String) -> Unit) {
    var numeroControl by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(scrollState)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.logo_tecnm),
            contentDescription = "Logo ITTG TecNM",
            modifier = Modifier
                .height(140.dp)
                .fillMaxWidth()
                .padding(bottom = 20.dp)
        )

        Text(
            text = "Acceso TecNM Tuxtla",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = TecNMAzulMarino,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        OutlinedTextField(
            value = numeroControl,
            onValueChange = { nuevoTexto ->
                if (nuevoTexto.all { it.isDigit() } && nuevoTexto.length <= 8) {
                    numeroControl = nuevoTexto
                }
            },
            label = { Text("Número de Control (8 dígitos)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = TecNMAzulMarino,
                focusedLabelColor = TecNMAzulMarino
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            shape = RoundedCornerShape(12.dp)
        )

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Contraseña") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = TecNMAzulMarino,
                focusedLabelColor = TecNMAzulMarino
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            shape = RoundedCornerShape(12.dp)
        )

        Button(
            onClick = {
                if (numeroControl == NUMERO_CONTROL_VALIDO && password == PASSWORD_VALIDA) {
                    onLoginSuccess(numeroControl)
                } else {
                    Toast.makeText(
                        context,
                        "Número de control o contraseña incorrectos",
                        Toast.LENGTH_LONG
                    ).show()
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = TecNMAzulMarino),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(text = "Iniciar Sesión", fontSize = 16.sp, color = Color.White)
        }
    }
}

@Composable
fun ProfileScreen(numeroControl: String, onLogout: () -> Unit) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    // Cargar la imagen guardada localmente si existe
    var profileBitmap by remember { mutableStateOf(cargarImagenLocal(context)) }

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            val nuevoBitmap = obtenerBitmapDeUri(context, it)
            if (nuevoBitmap != null) {
                guardarImagenLocal(context, nuevoBitmap)
                profileBitmap = nuevoBitmap
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(130.dp)
                .clip(CircleShape)
                .background(Color.LightGray)
                .clickable { galleryLauncher.launch("image/*") },
            contentAlignment = Alignment.Center
        ) {
            if (profileBitmap != null) {
                Image(
                    bitmap = profileBitmap!!.asImageBitmap(),
                    contentDescription = "Foto Seleccionada",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Image(
                    painter = painterResource(id = R.drawable.logo_tecnm),
                    contentDescription = "Foto por Defecto",
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp)
                )
            }
        }

        Text(
            text = "Toca la imagen para cambiar la foto",
            fontSize = 11.sp,
            color = Color.Gray,
            modifier = Modifier.padding(top = 8.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Perfil del Estudiante",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = TecNMAzulMarino
        )

        Spacer(modifier = Modifier.height(20.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                DatoPersonalItem(label = "Número de Control", valor = numeroControl)
                DatoPersonalItem(label = "Nombre Completo", valor = "Jonathan Alejandro Bonifaz Tapia")
                DatoPersonalItem(label = "Carrera", valor = "Ingeniería en Sistemas Computacionales")
                DatoPersonalItem(label = "Institución", valor = "TecNM - Instituto Tecnológico de Tuxtla Gutiérrez")
                DatoPersonalItem(label = "Semestre", valor = "9no Semestre")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onLogout,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(text = "Cerrar Sesión", fontSize = 16.sp, color = Color.White)
        }
    }
}

// Guarda la imagen de forma permanente en el almacenamiento de la app
fun guardarImagenLocal(context: Context, bitmap: Bitmap) {
    try {
        val file = File(context.filesDir, PROFILE_IMAGE_NAME)
        val stream = FileOutputStream(file)
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
        stream.flush()
        stream.close()
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

// Lee la imagen previamente guardada
fun cargarImagenLocal(context: Context): Bitmap? {
    val file = File(context.filesDir, PROFILE_IMAGE_NAME)
    return if (file.exists()) {
        BitmapFactory.decodeFile(file.absolutePath)
    } else {
        null
    }
}

fun obtenerBitmapDeUri(context: Context, uri: Uri): Bitmap? {
    return try {
        val inputStream = context.contentResolver.openInputStream(uri)
        BitmapFactory.decodeStream(inputStream)
    } catch (e: Exception) {
        null
    }
}

@Composable
fun DatoPersonalItem(label: String, valor: String) {
    Column {
        Text(
            text = label,
            fontSize = 12.sp,
            color = Color.Gray,
            fontWeight = FontWeight.Medium
        )
        Text(
            text = valor,
            fontSize = 15.sp,
            color = TecNMAzulMarino,
            fontWeight = FontWeight.SemiBold
        )
    }
}