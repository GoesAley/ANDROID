package com.example.a460a21sistemadegestiondemedicamentos.data

import com.example.a460a21sistemadegestiondemedicamentos.data.local.Converters
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.DayOfWeek
import java.time.LocalDateTime

class ConvertersTest {

    private val converters = Converters()

    @Test
    fun localDateTime_conversion_isCorrect() {
        val originalDateTime = LocalDateTime.of(2026, 10, 6, 8, 30, 0)
        val stringValue = converters.fromLocalDateTime(originalDateTime)
        val parsedDateTime = converters.toLocalDateTime(stringValue)

        assertEquals("2026-10-06T08:30:00", stringValue)
        assertEquals(originalDateTime, parsedDateTime)
    }

    @Test
    fun localDateTime_null_returnsNull() {
        assertNull(converters.fromLocalDateTime(null))
        assertNull(converters.toLocalDateTime(null))
    }

    @Test
    fun dayOfWeekList_conversion_isCorrect() {
        val days = listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY)
        val stringValue = converters.fromDayOfWeekList(days)
        val parsedDays = converters.toDayOfWeekList(stringValue)

        assertEquals("MONDAY,WEDNESDAY,FRIDAY", stringValue)
        assertEquals(days, parsedDays)
    }

    @Test
    fun dayOfWeekList_emptyAndNull_returnsEmptyList() {
        assertEquals("", converters.fromDayOfWeekList(emptyList()))
        assertEquals(emptyList<DayOfWeek>(), converters.toDayOfWeekList(""))
        assertEquals(emptyList<DayOfWeek>(), converters.toDayOfWeekList(null))
    }
}
