package com.example.a460a21sistemadegestiondemedicamentos.data

import com.example.a460a21sistemadegestiondemedicamentos.data.mapper.toDomain
import com.example.a460a21sistemadegestiondemedicamentos.data.mapper.toEntity
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.FrequencyType
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.DayOfWeek
import java.time.LocalDateTime

class MapperTest {

    @Test
    fun medication_entityToDomainAndBack_isConsistent() {
        val medication = Medication(
            id = 1L,
            name = "Paracetamol",
            dosage = "500 mg",
            frequencyType = FrequencyType.SPECIFIC_DAYS,
            intervalHours = null,
            specificDays = listOf(DayOfWeek.MONDAY, DayOfWeek.FRIDAY),
            cycleActiveDays = null,
            cycleRestDays = null,
            startDateTime = LocalDateTime.of(2026, 10, 6, 9, 0, 0),
            currentStock = 20,
            minStockThreshold = 5,
            isActive = true
        )

        val entity = medication.toEntity()
        val mappedDomain = entity.toDomain()

        assertEquals(medication, mappedDomain)
    }
}
