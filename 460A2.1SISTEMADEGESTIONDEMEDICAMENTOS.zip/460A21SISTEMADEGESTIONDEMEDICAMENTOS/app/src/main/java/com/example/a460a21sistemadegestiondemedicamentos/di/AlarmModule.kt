package com.example.a460a21sistemadegestiondemedicamentos.di

import com.example.a460a21sistemadegestiondemedicamentos.data.alarm.AlarmSchedulerImpl
import com.example.a460a21sistemadegestiondemedicamentos.domain.alarm.AlarmScheduler
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class AlarmModule {

    @Binds
    @Singleton
    abstract fun bindAlarmScheduler(
        impl: AlarmSchedulerImpl
    ): AlarmScheduler
}
