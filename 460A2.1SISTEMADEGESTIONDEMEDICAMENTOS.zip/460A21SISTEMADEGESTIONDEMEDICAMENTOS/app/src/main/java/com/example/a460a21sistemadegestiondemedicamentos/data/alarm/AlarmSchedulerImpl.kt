package com.example.a460a21sistemadegestiondemedicamentos.data.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.a460a21sistemadegestiondemedicamentos.domain.alarm.AlarmScheduler
import com.example.a460a21sistemadegestiondemedicamentos.domain.alarm.DoseCalculator
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import dagger.hilt.android.qualifiers.ApplicationContext
import java.time.LocalDateTime
import java.time.ZoneId
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AlarmSchedulerImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val doseCalculator: DoseCalculator
) : AlarmScheduler {

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    override fun scheduleNextAlarm(medication: Medication) {
        if (!medication.isActive) return

        val nextDose = doseCalculator.calculateNextDose(medication, LocalDateTime.now())
        val epochMilli = nextDose.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = NotificationHelper.ACTION_TRIGGER_NOTIFICATION
            putExtra(NotificationHelper.EXTRA_MEDICATION_ID, medication.id)
            putExtra(NotificationHelper.EXTRA_MEDICATION_NAME, medication.name)
            putExtra(NotificationHelper.EXTRA_MEDICATION_DOSAGE, medication.dosage)
            putExtra(NotificationHelper.EXTRA_SCHEDULED_TIME, nextDose.toString())
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            medication.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    epochMilli,
                    pendingIntent
                )
            } else {
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    epochMilli,
                    pendingIntent
                )
            }
        } else {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                epochMilli,
                pendingIntent
            )
        }
    }

    override fun cancelAlarm(medicationId: Long) {
        val intent = Intent(context, AlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            medicationId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }
}
