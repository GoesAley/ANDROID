package com.example.a460a21sistemadegestiondemedicamentos.ui.medication

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.a460a21sistemadegestiondemedicamentos.R
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.FrequencyType
import com.example.a460a21sistemadegestiondemedicamentos.ui.theme._460A21SISTEMADEGESTIONDEMEDICAMENTOSTheme
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter

@Composable
fun AddEditMedicationScreen(
    onNavigateBackWithResult: (String) -> Unit,
    onNavigateBack: () -> Unit,
    viewModel: AddEditMedicationViewModel = hiltViewModel()
) {
    val formState by viewModel.formState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.uiEvent.collect { event ->
            when (event) {
                is FormUiEvent.SaveSuccess -> {
                    val message = if (event.isEditMode) "Medicamento editado correctamente"
                    else "Medicamento agregado correctamente"
                    onNavigateBackWithResult(message)
                }
                is FormUiEvent.ShowError -> {
                    snackbarHostState.showSnackbar(event.message)
                }
            }
        }
    }

    AddEditMedicationContent(
        formState = formState,
        snackbarHostState = snackbarHostState,
        onNavigateBack = onNavigateBack,
        onNameChange = viewModel::onNameChange,
        onDosageChange = viewModel::onDosageChange,
        onFrequencyTypeChange = viewModel::onFrequencyTypeChange,
        onIntervalHoursChange = viewModel::onIntervalHoursChange,
        onDayToggle = viewModel::onDayToggle,
        onCycleActiveDaysChange = viewModel::onCycleActiveDaysChange,
        onCycleRestDaysChange = viewModel::onCycleRestDaysChange,
        onStartDateTimeChange = viewModel::onStartDateTimeChange,
        onCurrentStockChange = viewModel::onCurrentStockChange,
        onMinStockThresholdChange = viewModel::onMinStockThresholdChange,
        onSaveMedication = viewModel::saveMedication
    )
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddEditMedicationContent(
    formState: AddEditFormState,
    snackbarHostState: SnackbarHostState,
    onNavigateBack: () -> Unit,
    onNameChange: (String) -> Unit,
    onDosageChange: (String) -> Unit,
    onFrequencyTypeChange: (FrequencyType) -> Unit,
    onIntervalHoursChange: (String) -> Unit,
    onDayToggle: (DayOfWeek) -> Unit,
    onCycleActiveDaysChange: (String) -> Unit,
    onCycleRestDaysChange: (String) -> Unit,
    onStartDateTimeChange: (LocalDateTime) -> Unit,
    onCurrentStockChange: (String) -> Unit,
    onMinStockThresholdChange: (String) -> Unit,
    onSaveMedication: () -> Unit
) {
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (formState.isEditMode) stringResource(R.string.title_edit_medication)
                        else stringResource(R.string.title_add_medication)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Nombre (Texto)
            OutlinedTextField(
                value = formState.name,
                onValueChange = onNameChange,
                label = { Text(stringResource(R.string.label_name)) },
                placeholder = { Text(stringResource(R.string.hint_name)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                isError = formState.validationResult.nameError != null,
                supportingText = formState.validationResult.nameError?.let {
                    { Text(stringResource(it)) }
                },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            // Dosis (Texto / alfanumérico)
            OutlinedTextField(
                value = formState.dosage,
                onValueChange = onDosageChange,
                label = { Text(stringResource(R.string.label_dosage)) },
                placeholder = { Text(stringResource(R.string.hint_dosage)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                isError = formState.validationResult.dosageError != null,
                supportingText = formState.validationResult.dosageError?.let {
                    { Text(stringResource(it)) }
                },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            // Selector de Frecuencia
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = stringResource(R.string.label_frequency_type),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    FrequencyTypeOption(
                        selected = formState.frequencyType == FrequencyType.EVERY_X_HOURS,
                        label = stringResource(R.string.freq_every_x_hours),
                        onSelect = { onFrequencyTypeChange(FrequencyType.EVERY_X_HOURS) }
                    )

                    FrequencyTypeOption(
                        selected = formState.frequencyType == FrequencyType.SPECIFIC_DAYS,
                        label = stringResource(R.string.freq_specific_days),
                        onSelect = { onFrequencyTypeChange(FrequencyType.SPECIFIC_DAYS) }
                    )

                    FrequencyTypeOption(
                        selected = formState.frequencyType == FrequencyType.ALTERNATE_DAYS,
                        label = stringResource(R.string.freq_alternate_days),
                        onSelect = { onFrequencyTypeChange(FrequencyType.ALTERNATE_DAYS) }
                    )

                    FrequencyTypeOption(
                        selected = formState.frequencyType == FrequencyType.CYCLE,
                        label = stringResource(R.string.freq_cycle),
                        onSelect = { onFrequencyTypeChange(FrequencyType.CYCLE) }
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Campos dinámicos según el tipo de frecuencia (NUMÉRICOS)
                    when (formState.frequencyType) {
                        FrequencyType.EVERY_X_HOURS -> {
                            OutlinedTextField(
                                value = formState.intervalHours,
                                onValueChange = onIntervalHoursChange,
                                label = { Text(stringResource(R.string.label_interval_hours)) },
                                placeholder = { Text(stringResource(R.string.hint_interval_hours)) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                isError = formState.validationResult.intervalError != null,
                                supportingText = formState.validationResult.intervalError?.let {
                                    { Text(stringResource(it)) }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp)
                            )
                        }
                        FrequencyType.SPECIFIC_DAYS -> {
                            Text(
                                text = stringResource(R.string.label_specific_days),
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                DayOfWeek.entries.forEach { day ->
                                    val isSelected = formState.specificDays.contains(day)
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { onDayToggle(day) },
                                        label = { Text(getDayAbbreviation(day)) }
                                    )
                                }
                            }
                            formState.validationResult.specificDaysError?.let {
                                Text(
                                    text = stringResource(it),
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                        FrequencyType.ALTERNATE_DAYS -> {
                            Text(
                                text = "El medicamento se tomará un día sí y un día no, comenzando desde la fecha de inicio.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        FrequencyType.CYCLE -> {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                OutlinedTextField(
                                    value = formState.cycleActiveDays,
                                    onValueChange = onCycleActiveDaysChange,
                                    label = { Text(stringResource(R.string.label_cycle_active)) },
                                    placeholder = { Text(stringResource(R.string.hint_cycle_active)) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    isError = formState.validationResult.cycleActiveError != null,
                                    supportingText = formState.validationResult.cycleActiveError?.let {
                                        { Text(stringResource(it)) }
                                    },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                OutlinedTextField(
                                    value = formState.cycleRestDays,
                                    onValueChange = onCycleRestDaysChange,
                                    label = { Text(stringResource(R.string.label_cycle_rest)) },
                                    placeholder = { Text(stringResource(R.string.hint_cycle_rest)) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    isError = formState.validationResult.cycleRestError != null,
                                    supportingText = formState.validationResult.cycleRestError?.let {
                                        { Text(stringResource(it)) }
                                    },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true,
                                    shape = RoundedCornerShape(12.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Fecha y Hora de Inicio
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = stringResource(R.string.label_start_date_time),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    val formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")
                    Text(
                        text = formState.startDateTime.format(formatter),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.secondary
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                val current = formState.startDateTime
                                DatePickerDialog(
                                    context,
                                    { _, year, month, dayOfMonth ->
                                        val newDate = LocalDate.of(year, month + 1, dayOfMonth)
                                        onStartDateTimeChange(
                                            LocalDateTime.of(newDate, current.toLocalTime())
                                        )
                                    },
                                    current.year,
                                    current.monthValue - 1,
                                    current.dayOfMonth
                                ).show()
                            },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.DateRange, contentDescription = null)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Cambiar Fecha")
                        }

                        OutlinedButton(
                            onClick = {
                                val current = formState.startDateTime
                                TimePickerDialog(
                                    context,
                                    { _, hourOfDay, minute ->
                                        val newTime = LocalTime.of(hourOfDay, minute)
                                        onStartDateTimeChange(
                                            LocalDateTime.of(current.toLocalDate(), newTime)
                                        )
                                    },
                                    current.hour,
                                    current.minute,
                                    true
                                ).show()
                            },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Cambiar Hora")
                        }
                    }
                }
            }

            // Stock e Inventario (NUMÉRICOS)
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = formState.currentStock,
                    onValueChange = onCurrentStockChange,
                    label = { Text(stringResource(R.string.label_current_stock)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    isError = formState.validationResult.stockError != null,
                    supportingText = formState.validationResult.stockError?.let {
                        { Text(stringResource(it)) }
                    },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = formState.minStockThreshold,
                    onValueChange = onMinStockThresholdChange,
                    label = { Text(stringResource(R.string.label_min_stock_threshold)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    isError = formState.validationResult.minThresholdError != null,
                    supportingText = formState.validationResult.minThresholdError?.let {
                        { Text(stringResource(it)) }
                    },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Botón Guardar
            Button(
                onClick = onSaveMedication,
                enabled = !formState.isSaving,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Text(
                    text = stringResource(R.string.save),
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }
    }
}

@Composable
fun FrequencyTypeOption(
    selected: Boolean,
    label: String,
    onSelect: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        RadioButton(
            selected = selected,
            onClick = onSelect
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(start = 8.dp)
        )
    }
}

@Composable
fun getDayAbbreviation(day: DayOfWeek): String {
    return when (day) {
        DayOfWeek.MONDAY -> stringResource(R.string.day_mon)
        DayOfWeek.TUESDAY -> stringResource(R.string.day_tue)
        DayOfWeek.WEDNESDAY -> stringResource(R.string.day_wed)
        DayOfWeek.THURSDAY -> stringResource(R.string.day_thu)
        DayOfWeek.FRIDAY -> stringResource(R.string.day_fri)
        DayOfWeek.SATURDAY -> stringResource(R.string.day_sat)
        DayOfWeek.SUNDAY -> stringResource(R.string.day_sun)
    }
}

@Preview(showBackground = true)
@Composable
fun AddEditMedicationScreenPreview() {
    _460A21SISTEMADEGESTIONDEMEDICAMENTOSTheme {
        AddEditMedicationContent(
            formState = AddEditFormState(
                name = "Paracetamol",
                dosage = "500 mg",
                frequencyType = FrequencyType.EVERY_X_HOURS,
                intervalHours = "8",
                currentStock = "30",
                minStockThreshold = "5"
            ),
            snackbarHostState = remember { SnackbarHostState() },
            onNavigateBack = {},
            onNameChange = {},
            onDosageChange = {},
            onFrequencyTypeChange = {},
            onIntervalHoursChange = {},
            onDayToggle = {},
            onCycleActiveDaysChange = {},
            onCycleRestDaysChange = {},
            onStartDateTimeChange = {},
            onCurrentStockChange = {},
            onMinStockThresholdChange = {},
            onSaveMedication = {}
        )
    }
}
