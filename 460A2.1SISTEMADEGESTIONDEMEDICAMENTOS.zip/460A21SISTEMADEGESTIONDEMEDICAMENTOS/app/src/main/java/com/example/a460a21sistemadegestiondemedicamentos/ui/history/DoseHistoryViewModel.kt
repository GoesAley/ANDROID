package com.example.a460a21sistemadegestiondemedicamentos.ui.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import com.example.a460a21sistemadegestiondemedicamentos.domain.repository.MedicationRepository
import com.example.a460a21sistemadegestiondemedicamentos.domain.usecase.DoseHistoryDisplayItem
import com.example.a460a21sistemadegestiondemedicamentos.domain.usecase.GetDoseHistoryUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import javax.inject.Inject

data class HistoryFilterState(
    val selectedMedicationId: Long? = null,
    val startDate: LocalDate? = null,
    val endDate: LocalDate? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class DoseHistoryViewModel @Inject constructor(
    private val getDoseHistoryUseCase: GetDoseHistoryUseCase,
    private val medicationRepository: MedicationRepository
) : ViewModel() {

    val availableMedications: StateFlow<List<Medication>> = medicationRepository.getAllMedications()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _filterState = MutableStateFlow(HistoryFilterState())
    val filterState: StateFlow<HistoryFilterState> = _filterState.asStateFlow()

    val historyItems: StateFlow<List<DoseHistoryDisplayItem>> = _filterState
        .flatMapLatest { filter ->
            val startDateTime = filter.startDate?.let { LocalDateTime.of(it, LocalTime.MIN) }
            val endDateTime = filter.endDate?.let { LocalDateTime.of(it, LocalTime.MAX) }

            getDoseHistoryUseCase(
                medicationIdFilter = filter.selectedMedicationId,
                startDateFilter = startDateTime,
                endDateFilter = endDateTime
            )
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun onSelectMedicationFilter(medicationId: Long?) {
        _filterState.value = _filterState.value.copy(selectedMedicationId = medicationId)
    }

    fun onDateRangeSelected(startDate: LocalDate?, endDate: LocalDate?) {
        _filterState.value = _filterState.value.copy(startDate = startDate, endDate = endDate)
    }

    fun clearFilters() {
        _filterState.value = HistoryFilterState()
    }
}
