package com.example.a460a21sistemadegestiondemedicamentos.data.alarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.a460a21sistemadegestiondemedicamentos.MainActivity
import com.example.a460a21sistemadegestiondemedicamentos.R
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationHelper @Inject constructor(
    @ApplicationContext private val context: Context
) {

    companion object {
        const val CHANNEL_ID = "medication_reminders_channel"
        const val CHANNEL_NAME = "Recordatorios de Medicamentos"

        const val ACTION_TRIGGER_NOTIFICATION = "com.example.ACTION_TRIGGER_NOTIFICATION"
        const val ACTION_TAKEN = "com.example.ACTION_TAKEN"
        const val ACTION_POSTPONE = "com.example.ACTION_POSTPONE"
        const val EXTRA_MEDICATION_ID = "extra_medication_id"
        const val EXTRA_MEDICATION_NAME = "extra_medication_name"
        const val EXTRA_MEDICATION_DOSAGE = "extra_medication_dosage"
        const val EXTRA_SCHEDULED_TIME = "extra_scheduled_time"
        const val EXTRA_IS_POSTPONED = "extra_is_postponed"
    }

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                .build()

            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notificaciones elegantes de recordatorio de medicamentos en barra de estado"
                enableVibration(true)
                setSound(soundUri, audioAttributes)
            }

            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    fun showMedicationNotification(
        medication: Medication,
        scheduledTimeIso: String,
        isPostponed: Boolean = false
    ) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            context,
            medication.id.toInt(),
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val takenIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_TAKEN
            putExtra(EXTRA_MEDICATION_ID, medication.id)
            putExtra(EXTRA_MEDICATION_NAME, medication.name)
            putExtra(EXTRA_SCHEDULED_TIME, scheduledTimeIso)
        }
        val takenPendingIntent = PendingIntent.getBroadcast(
            context,
            (medication.id * 10 + 1).toInt(),
            takenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val postponeIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_POSTPONE
            putExtra(EXTRA_MEDICATION_ID, medication.id)
            putExtra(EXTRA_MEDICATION_NAME, medication.name)
            putExtra(EXTRA_SCHEDULED_TIME, scheduledTimeIso)
        }
        val postponePendingIntent = PendingIntent.getBroadcast(
            context,
            (medication.id * 10 + 2).toInt(),
            postponeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val titleText = if (isPostponed) "⏰ Recordatorio Pospuesto: ${medication.name}" else "Recordatorio: ${medication.name}"
        val bodyText = if (isPostponed) {
            "Dosis pospuesta (${medication.dosage}). ¡Es momento de tomar tu medicamento!"
        } else {
            "Es hora de tomar tu medicamento: ${medication.name} (${medication.dosage})."
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(titleText)
            .setContentText("Dosis: ${medication.dosage}")
            .setStyle(NotificationCompat.BigTextStyle().bigText(bodyText))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setSound(soundUri)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true)
            .setContentIntent(openAppPendingIntent)
            .addAction(R.mipmap.ic_launcher, "Tomada", takenPendingIntent)
            .addAction(R.mipmap.ic_launcher, "Posponer 15 min", postponePendingIntent)
            .build()

        notificationManager.notify(medication.id.toInt(), notification)
    }

    fun showPostponedConfirmationNotification(medication: Medication, minutes: Int = 15) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Toma pospuesta")
            .setContentText("Se ha pospuesto la toma de \"${medication.name}\" por $minutes minutos.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        notificationManager.notify((medication.id + 10000).toInt(), notification)
    }

    fun dismissNotification(medicationId: Long) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.cancel(medicationId.toInt())
    }
}
