package com.example.a460a22mikardex

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.a460a22mikardex.data.local.AppDatabase
import com.example.a460a22mikardex.data.local.PreferenciasAlumnoManager
import com.example.a460a22mikardex.data.repository.KardexRepository
import com.example.a460a22mikardex.ui.screens.KardexSingleScreen
import com.example.a460a22mikardex.ui.theme._460A22MIKARDEXTheme
import com.example.a460a22mikardex.ui.viewmodel.KardexMainViewModel
import com.example.a460a22mikardex.ui.viewmodel.KardexMainViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Inicializar fuentes de datos y repositorio
        val database = AppDatabase.getInstance(applicationContext)
        val preferenciasManager = PreferenciasAlumnoManager(applicationContext)
        val repository = KardexRepository(database.materiaDao(), preferenciasManager)

        setContent {
            _460A22MIKARDEXTheme {
                val viewModel: KardexMainViewModel = viewModel(
                    factory = KardexMainViewModelFactory(repository)
                )
                KardexSingleScreen(viewModel = viewModel)
            }
        }
    }
}
