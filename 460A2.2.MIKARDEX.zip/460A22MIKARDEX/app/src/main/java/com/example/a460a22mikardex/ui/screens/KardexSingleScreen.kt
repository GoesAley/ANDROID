package com.example.a460a22mikardex.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCard
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Grade
import androidx.compose.material.icons.filled.Numbers
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.a460a22mikardex.data.local.EstatusMateria
import com.example.a460a22mikardex.data.local.MateriaKardex
import com.example.a460a22mikardex.ui.components.ConfirmationDialog
import com.example.a460a22mikardex.ui.theme._460A22MIKARDEXTheme
import com.example.a460a22mikardex.ui.viewmodel.KardexMainViewModel
import com.example.a460a22mikardex.ui.viewmodel.MateriaFormUiState
import com.example.a460a22mikardex.ui.viewmodel.PerfilUiState

/**
 * Componente contenedor con estado para la Pantalla Única de "Kardex Académico".
 */
@Composable
fun KardexSingleScreen(viewModel: KardexMainViewModel) {
    val perfilState by viewModel.perfilState.collectAsState()
    val formState by viewModel.materiaFormState.collectAsState()
    val promedioGeneral by viewModel.promedioGeneral.collectAsState()
    val promedioPorSemestre by viewModel.promedioPorSemestre.collectAsState()
    val semestreFiltro by viewModel.semestreFiltro.collectAsState()
    val materias by viewModel.todasLasMaterias.collectAsState()
    val materiaAEliminar by viewModel.materiaAEliminar.collectAsState()

    KardexSingleScreenContent(
        perfilState = perfilState,
        formState = formState,
        promedioGeneral = promedioGeneral,
        promedioPorSemestre = promedioPorSemestre,
        semestreFiltro = semestreFiltro,
        materias = materias,
        materiaAEliminar = materiaAEliminar,
        onNombrePerfilChanged = viewModel::onNombrePerfilChanged,
        onNumeroControlPerfilChanged = viewModel::onNumeroControlPerfilChanged,
        onGuardarPerfilClick = { viewModel.guardarDatosPersonales() },
        onEditarPerfilClick = { viewModel.activarEdicionPerfil() },
        onLimpiarMensajePerfil = viewModel::limpiarMensajeExitoPerfil,
        onNombreMateriaChanged = viewModel::onNombreMateriaChanged,
        onSemestreMateriaChanged = viewModel::onSemestreMateriaChanged,
        onOportunidadMateriaChanged = viewModel::onOportunidadMateriaChanged,
        onCalificacionMateriaChanged = viewModel::onCalificacionMateriaChanged,
        onSemestreFiltroChanged = viewModel::onSemestreFiltroChanged,
        onGuardarMateriaClick = { viewModel.guardarMateria() },
        onLimpiarMensajeMateria = viewModel::limpiarMensajeExitoMateria,
        onDeleteMateriaClick = viewModel::solicitarEliminacion,
        onConfirmDelete = viewModel::confirmarEliminacion,
        onDismissDelete = viewModel::cancelarEliminacion
    )
}

/**
 * Componente visual sin estado (Stateless) para la pantalla única.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KardexSingleScreenContent(
    perfilState: PerfilUiState,
    formState: MateriaFormUiState,
    promedioGeneral: String,
    promedioPorSemestre: String,
    semestreFiltro: String,
    materias: List<MateriaKardex>,
    materiaAEliminar: MateriaKardex?,
    onNombrePerfilChanged: (String) -> Unit,
    onNumeroControlPerfilChanged: (String) -> Unit,
    onGuardarPerfilClick: () -> Unit,
    onEditarPerfilClick: () -> Unit,
    onLimpiarMensajePerfil: () -> Unit,
    onNombreMateriaChanged: (String) -> Unit,
    onSemestreMateriaChanged: (String) -> Unit,
    onOportunidadMateriaChanged: (String) -> Unit,
    onCalificacionMateriaChanged: (String) -> Unit,
    onSemestreFiltroChanged: (String) -> Unit,
    onGuardarMateriaClick: () -> Unit,
    onLimpiarMensajeMateria: () -> Unit,
    onDeleteMateriaClick: (MateriaKardex) -> Unit,
    onConfirmDelete: () -> Unit,
    onDismissDelete: () -> Unit
) {
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(perfilState.mensajeExito) {
        perfilState.mensajeExito?.let { mensaje ->
            snackbarHostState.showSnackbar(mensaje)
            onLimpiarMensajePerfil()
        }
    }

    LaunchedEffect(formState.mensajeExito) {
        formState.mensajeExito?.let { mensaje ->
            snackbarHostState.showSnackbar(mensaje)
            onLimpiarMensajeMateria()
        }
    }

    // Diálogo de confirmación para eliminar materia
    materiaAEliminar?.let { materia ->
        ConfirmationDialog(
            titulo = "Eliminar Materia",
            mensaje = "¿Está seguro de eliminar '${materia.nombre}' (Semestre ${materia.semestre}) del kardex?",
            onConfirm = onConfirmDelete,
            onDismiss = onDismissDelete
        )
    }

    Scaffold(
        modifier = Modifier.imePadding(),
        topBar = {
            TopAppBar(
                title = { Text("Kardex Académico") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            // --- 1. DATOS PERSONALES (SharedPreferences) ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Datos Personales del Alumno",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            if (perfilState.estaGuardado && !perfilState.isEditing) {
                                Box(
                                    modifier = Modifier
                                        .background(
                                            color = MaterialTheme.colorScheme.primaryContainer,
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.height(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Guardado",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Campo Nombre Completo
                        OutlinedTextField(
                            value = perfilState.nombre,
                            onValueChange = onNombrePerfilChanged,
                            enabled = perfilState.isEditing,
                            label = { Text("Nombre Completo") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                            isError = perfilState.nombreError != null,
                            supportingText = { perfilState.nombreError?.let { Text(it) } },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // Campo Número de Control
                        OutlinedTextField(
                            value = perfilState.numeroControl,
                            onValueChange = onNumeroControlPerfilChanged,
                            enabled = perfilState.isEditing,
                            label = { Text("Número de Control") },
                            leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null) },
                            isError = perfilState.numeroControlError != null,
                            supportingText = { perfilState.numeroControlError?.let { Text(it) } },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        if (perfilState.isEditing) {
                            Button(
                                onClick = onGuardarPerfilClick,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Save, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Guardar Datos Personales")
                            }
                        } else {
                            Button(
                                onClick = onEditarPerfilClick,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Editar Datos Personales")
                            }
                        }
                    }
                }
            }

            // --- 2. CONSULTAS DE PROMEDIOS ACADÉMICOS ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Consultas de Promedios",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Promedio General:",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Text(
                                text = promedioGeneral,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = semestreFiltro,
                                onValueChange = onSemestreFiltroChanged,
                                label = { Text("Consultar Semestre") },
                                placeholder = { Text("1-12") },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )

                            Spacer(modifier = Modifier.width(16.dp))

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "Prom. Semestre:",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Text(
                                    text = promedioPorSemestre,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }
                }
            }

            // --- 3. CAPTURA DE MATERIA ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Captura de Materia",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        // Campo Nombre
                        OutlinedTextField(
                            value = formState.nombre,
                            onValueChange = onNombreMateriaChanged,
                            label = { Text("Nombre de la Materia") },
                            leadingIcon = { Icon(Icons.Default.Book, contentDescription = null) },
                            isError = formState.nombreError != null,
                            supportingText = { formState.nombreError?.let { Text(it) } },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // Campo Semestre
                        OutlinedTextField(
                            value = formState.semestre,
                            onValueChange = onSemestreMateriaChanged,
                            label = { Text("Semestre en que se cursa (1-12)") },
                            leadingIcon = { Icon(Icons.Default.Numbers, contentDescription = null) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            isError = formState.semestreError != null,
                            supportingText = { formState.semestreError?.let { Text(it) } },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Tipo de Curso / Oportunidad:",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // Selector de Oportunidad
                        val opcionesOportunidad = listOf("Normal", "Repetición", "Especial", "Verano")
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            opcionesOportunidad.forEach { opcion ->
                                FilterChip(
                                    selected = formState.oportunidad == opcion,
                                    onClick = { onOportunidadMateriaChanged(opcion) },
                                    label = { Text(opcion, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // 1 SOLO CAMPO HABILITADO PARA INGRESAR LA CALIFICACIÓN
                        OutlinedTextField(
                            value = formState.calificacion,
                            onValueChange = onCalificacionMateriaChanged,
                            label = { Text("Calificación en ${formState.oportunidad} (0-100)") },
                            leadingIcon = { Icon(Icons.Default.Grade, contentDescription = null) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            isError = formState.calificacionError != null,
                            supportingText = { formState.calificacionError?.let { Text(it) } },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = onGuardarMateriaClick,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.AddCard, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Guardar Materia en Base de Datos")
                        }
                    }
                }
            }

            // --- 4. HISTORIAL ACADÉMICO ORGANIZADO POR PILA DE SEMESTRES ---
            item {
                Text(
                    text = "Historial Registrado por Semestre",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            if (materias.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.School,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.outline
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Sin datos",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.outline
                                )
                                Text(
                                    text = "Aún no ha registrado materias en la base de datos.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                        }
                    }
                }
            } else {
                // Agrupar materias por semestre
                val materiasPorSemestre = materias.groupBy { it.semestre }.toSortedMap()

                materiasPorSemestre.forEach { (semestreNum, listaMaterias) ->
                    item(key = "header_semestre_$semestreNum") {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Semestre $semestreNum",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    text = "${listaMaterias.size} materia(s)",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                    }

                    items(listaMaterias, key = { it.id }) { materia ->
                        TarjetaMateriaItem(
                            materia = materia,
                            onDeleteClick = { onDeleteMateriaClick(materia) }
                        )
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}

/**
 * Tarjeta de Materia individual que muestra la calificación y resalta el estatus en colores:
 * - Azul: Acreditada
 * - Amarillo: Va a Repetición
 * - Anaranjado: Va a Curso Especial
 * - Rojo: Sin Oportunidad
 */
@Composable
fun TarjetaMateriaItem(
    materia: MateriaKardex,
    onDeleteClick: () -> Unit
) {
    // Colores según el estatus de la materia
    val (bgColor, textColor, textoBadge) = when (materia.estatus) {
        EstatusMateria.ACREDITADA -> Triple(
            Color(0xFFE3F2FD), // Azul claro
            Color(0xFF0D47A1), // Azul oscuro
            "Acreditada (${materia.oportunidadCursada})"
        )
        EstatusMateria.VA_A_REPETICION -> Triple(
            Color(0xFFFFF9C4), // Amarillo claro
            Color(0xFFF57F17), // Amarillo/Café oscuro
            "Va a Repetición (N/A)"
        )
        EstatusMateria.VA_A_ESPECIAL -> Triple(
            Color(0xFFFFE0B2), // Anaranjado claro
            Color(0xFFE65100), // Anaranjado oscuro
            "Va a Curso Especial (N/A)"
        )
        EstatusMateria.SIN_OPORTUNIDAD -> Triple(
            Color(0xFFFFCDD2), // Rojo claro
            Color(0xFFB71C1C), // Rojo oscuro
            "Sin Oportunidad (N/A)"
        )
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = materia.nombre,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Semestre ${materia.semestre} | Curso: ${materia.oportunidadCursada}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Calificación: ",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = materia.calificacionMostrar,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = textColor
                    )

                    Spacer(modifier = Modifier.width(10.dp))

                    // Badge resaltado según color
                    Box(
                        modifier = Modifier
                            .background(color = bgColor, shape = RoundedCornerShape(12.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = textoBadge,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = textColor
                        )
                    }
                }
            }

            IconButton(onClick = onDeleteClick) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Eliminar Materia",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

/**
 * Vista previa oficial para Android Studio (Compose Preview).
 */
@Preview(showBackground = true, showSystemUi = true)
@Composable
fun KardexSingleScreenPreview() {
    _460A22MIKARDEXTheme {
        KardexSingleScreenContent(
            perfilState = PerfilUiState(
                nombre = "Juan Carlos Pérez",
                numeroControl = "20261234",
                isEditing = false,
                estaGuardado = true
            ),
            formState = MateriaFormUiState(
                nombre = "Cálculo Integral",
                semestre = "2",
                oportunidad = "Normal",
                calificacion = "90"
            ),
            promedioGeneral = "88.50",
            promedioPorSemestre = "90.00",
            semestreFiltro = "1",
            materias = listOf(
                MateriaKardex(1, "Álgebra Lineal", 1, normal = 85.0),
                MateriaKardex(2, "Cálculo Diferencial", 1, normal = 50.0), // Amarillo -> Va a Repetición
                MateriaKardex(3, "Física General", 1, repeticion = 60.0),  // Anaranjado -> Va a Curso Especial
                MateriaKardex(4, "Química", 2, especial = 40.0)             // Rojo -> Sin Oportunidad
            ),
            materiaAEliminar = null,
            onNombrePerfilChanged = {},
            onNumeroControlPerfilChanged = {},
            onGuardarPerfilClick = {},
            onEditarPerfilClick = {},
            onLimpiarMensajePerfil = {},
            onNombreMateriaChanged = {},
            onSemestreMateriaChanged = {},
            onOportunidadMateriaChanged = {},
            onCalificacionMateriaChanged = {},
            onSemestreFiltroChanged = {},
            onGuardarMateriaClick = {},
            onLimpiarMensajeMateria = {},
            onDeleteMateriaClick = {},
            onConfirmDelete = {},
            onDismissDelete = {}
        )
    }
}
