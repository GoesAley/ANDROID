package com.example.a460a21sistemadegestiondemedicamentos

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MedicationApp : Application()
