package com.example.a460a21sistemadegestiondemedicamentos.domain.alarm

import com.example.a460a21sistemadegestiondemedicamentos.domain.model.FrequencyType
import com.example.a460a21sistemadegestiondemedicamentos.domain.model.Medication
import java.time.Duration
import java.time.LocalDateTime
import javax.inject.Inject

/**
 * Clase independiente y fácilmente testeable para calcular la fecha y hora de la próxima toma
 * según el tipo de frecuencia del medicamento (MED-06 / Frecuencias Avanzadas).
 */
class DoseCalculator @Inject constructor() {

    /**
     * Calcula la fecha y hora de la siguiente dosis válida igual o posterior a [fromDateTime].
     */
    fun calculateNextDose(medication: Medication, fromDateTime: LocalDateTime = LocalDateTime.now()): LocalDateTime {
        val start = medication.startDateTime

        // Si la fecha de inicio no es anterior al tiempo de referencia, la primera toma es exactamente la fecha de inicio
        if (!start.isBefore(fromDateTime)) {
            return start
        }

        return when (medication.frequencyType) {
            FrequencyType.EVERY_X_HOURS -> {
                val interval = medication.intervalHours ?: 8
                val hoursBetween = Duration.between(start, fromDateTime).toHours()
                val steps = (hoursBetween / interval) + 1
                start.plusHours(steps * interval)
            }

            FrequencyType.SPECIFIC_DAYS -> {
                val days = medication.specificDays
                if (days.isEmpty()) return fromDateTime.plusDays(1)

                val candidate = if (fromDateTime.isBefore(start)) start else fromDateTime.plusMinutes(1)
                val targetTime = start.toLocalTime()

                for (i in 0..14) { // Buscar en los próximos 14 días
                    val checkDate = candidate.plusDays(i.toLong())
                    if (days.contains(checkDate.dayOfWeek)) {
                        val candidateDateTime = LocalDateTime.of(checkDate.toLocalDate(), targetTime)
                        if (candidateDateTime.isAfter(fromDateTime)) {
                            return candidateDateTime
                        }
                    }
                }
                fromDateTime.plusDays(1)
            }

            FrequencyType.ALTERNATE_DAYS -> {
                val daysBetween = Duration.between(start.toLocalDate().atStartOfDay(), fromDateTime.toLocalDate().atStartOfDay()).toDays()
                val isEvenDay = daysBetween % 2 == 0L
                val timeOfStart = start.toLocalTime()

                if (isEvenDay) {
                    val candidate = LocalDateTime.of(fromDateTime.toLocalDate(), timeOfStart)
                    if (candidate.isAfter(fromDateTime)) {
                        candidate
                    } else {
                        LocalDateTime.of(fromDateTime.toLocalDate().plusDays(2), timeOfStart)
                    }
                } else {
                    LocalDateTime.of(fromDateTime.toLocalDate().plusDays(1), timeOfStart)
                }
            }

            FrequencyType.CYCLE -> {
                val active = medication.cycleActiveDays ?: 21
                val rest = medication.cycleRestDays ?: 7
                val cycleLength = active + rest
                if (cycleLength <= 0) return fromDateTime.plusDays(1)

                val targetTime = start.toLocalTime()
                var checkDate = if (fromDateTime.isBefore(start)) start.toLocalDate() else fromDateTime.toLocalDate()

                for (step in 0..60) {
                    val daysFromStart = Duration.between(start.toLocalDate().atStartOfDay(), checkDate.atStartOfDay()).toDays()
                    if (daysFromStart >= 0) {
                        val dayInCycle = (daysFromStart % cycleLength).toInt()
                        if (dayInCycle < active) {
                            val candidate = LocalDateTime.of(checkDate, targetTime)
                            if (candidate.isAfter(fromDateTime)) {
                                return candidate
                            }
                        }
                    }
                    checkDate = checkDate.plusDays(1)
                }
                fromDateTime.plusDays(1)
            }
        }
    }

    /**
     * Previsualiza todas las tomas programadas dentro de un rango de fechas para la vista de calendario (MED-06).
     */
    fun previewScheduleForDateRange(
        medication: Medication,
        rangeStart: LocalDateTime,
        rangeEnd: LocalDateTime
    ): List<LocalDateTime> {
        val schedule = mutableListOf<LocalDateTime>()
        var next = calculateNextDose(medication, rangeStart.minusNanos(1))

        while (next.isBefore(rangeEnd) || next.isEqual(rangeEnd)) {
            schedule.add(next)
            val subsequent = calculateNextDose(medication, next)
            if (subsequent.isAfter(next)) {
                next = subsequent
            } else {
                break
            }
        }
        return schedule
    }
}
