package com.example.a460a21sistemadegestiondemedicamentos.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.a460a21sistemadegestiondemedicamentos.data.local.entity.DoseLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DoseLogDao {

    @Query("SELECT * FROM dose_logs ORDER BY scheduledDateTime DESC")
    fun getAllDoseLogs(): Flow<List<DoseLogEntity>>

    @Query("SELECT * FROM dose_logs WHERE medicationId = :medicationId ORDER BY scheduledDateTime DESC")
    fun getDoseLogsByMedication(medicationId: Long): Flow<List<DoseLogEntity>>

    @Query("SELECT * FROM dose_logs WHERE scheduledDateTime BETWEEN :startDate AND :endDate ORDER BY scheduledDateTime DESC")
    fun getDoseLogsByDateRange(startDate: String, endDate: String): Flow<List<DoseLogEntity>>

    @Query("SELECT * FROM dose_logs WHERE medicationId = :medicationId AND scheduledDateTime BETWEEN :startDate AND :endDate ORDER BY scheduledDateTime DESC")
    fun getDoseLogsByMedicationAndDateRange(medicationId: Long, startDate: String, endDate: String): Flow<List<DoseLogEntity>>

    @Query("SELECT * FROM dose_logs WHERE id = :id")
    suspend fun getDoseLogById(id: Long): DoseLogEntity?

    @Query("SELECT * FROM dose_logs WHERE medicationId = :medicationId AND scheduledDateTime = :scheduledDateTime LIMIT 1")
    suspend fun getDoseLogByScheduledTime(medicationId: Long, scheduledDateTime: String): DoseLogEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDoseLog(doseLog: DoseLogEntity): Long

    @Update
    suspend fun updateDoseLog(doseLog: DoseLogEntity)

    @Query("DELETE FROM dose_logs WHERE medicationId = :medicationId")
    suspend fun deleteLogsForMedication(medicationId: Long): Int
}
