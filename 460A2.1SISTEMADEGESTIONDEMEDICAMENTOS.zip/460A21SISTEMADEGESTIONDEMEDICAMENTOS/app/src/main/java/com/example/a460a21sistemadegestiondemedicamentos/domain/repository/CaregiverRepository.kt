package com.example.a460a21sistemadegestiondemedicamentos.domain.repository

// Módulo de cuidador removido según especificación
